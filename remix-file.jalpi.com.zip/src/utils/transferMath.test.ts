import test from 'node:test';
import assert from 'node:assert/strict';
import {
  calculatePrice,
  calculatePriceWithCredit,
  calculateTransferSpeedMbps,
  computeBilledGb,
  formatBytes,
  formatCompactPrice,
  formatGbDisplay,
  formatTransferSpeedMbps,
  MB_BYTES,
  screenFileNames,
  sliderIndexToGb,
  smoothTransferSpeedMbps,
} from './transferMath';

test('formatBytes formats bytes cleanly across B, KB, MB, GB, TB', () => {
  assert.equal(formatBytes(0), '0 B');
  assert.equal(formatBytes(512), '512 B');
  assert.equal(formatBytes(1024), '1 KB');
  assert.equal(formatBytes(819 * 1024 * 1024), '819 MB');
  assert.equal(formatBytes(3.4 * 1024 * 1024 * 1024), '3.4 GB');
});

test('computeBilledGb rounds up to whole GB with 1 GB minimum', () => {
  assert.equal(computeBilledGb(0), 1);
  assert.equal(computeBilledGb(500 * 1024 * 1024), 1);
  assert.equal(computeBilledGb(6.3 * 1024 * 1024 * 1024), 7);
});

test('calculatePrice applies per-GB rate and minimum card charge in USD and INR', () => {
  const usdMin = calculatePrice(1, 'p2p', 'USD');
  assert.equal(usdMin.formatted, '$0.50');
  assert.equal(usdMin.isMinimumApplied, true);

  const usdTen = calculatePrice(10, 'p2p', 'USD');
  assert.equal(usdTen.formatted, '$0.50');
  assert.equal(usdTen.isMinimumApplied, false);

  const usdUploadTen = calculatePrice(10, 'server', 'USD');
  assert.equal(usdUploadTen.formatted, '$1.00');
  assert.equal(formatCompactPrice(usdUploadTen.amount, 'USD'), '$1');

  const inrTen = calculatePrice(10, 'p2p', 'INR');
  assert.equal(inrTen.formatted, '₹10');
  assert.equal(inrTen.gatewayLabel, 'Razorpay · UPI or card');
});

test('calculatePriceWithCredit covers 1 GB fully for free and discounts larger transfers', () => {
  const freeUsd = calculatePriceWithCredit(1, 'p2p', 'USD', 1);
  assert.equal(freeUsd.creditAppliedGb, 1);
  assert.equal(freeUsd.remainingBilledGb, 0);
  assert.equal(freeUsd.amount, 0);
  assert.equal(freeUsd.formatted, '$0.00');
  assert.equal(freeUsd.savingsFormatted, '$0.50');

  const freeInr = calculatePriceWithCredit(1, 'server', 'INR', 1);
  assert.equal(freeInr.creditAppliedGb, 1);
  assert.equal(freeInr.amount, 0);
  assert.equal(freeInr.formatted, '₹0');

  const partialInr = calculatePriceWithCredit(5, 'p2p', 'INR', 1);
  assert.equal(partialInr.creditAppliedGb, 1);
  assert.equal(partialInr.remainingBilledGb, 4);
  assert.equal(partialInr.amount, 4);
  assert.equal(partialInr.formatted, '₹4');
  assert.equal(partialInr.savingsFormatted, '₹1');

  const partialUsdVault = calculatePriceWithCredit(8, 'server', 'USD', 1);
  assert.equal(partialUsdVault.creditAppliedGb, 1);
  assert.equal(partialUsdVault.remainingBilledGb, 7);
  assert.equal(partialUsdVault.amount, 0.7);
  assert.equal(partialUsdVault.formatted, '$0.70');
  assert.equal(partialUsdVault.savingsFormatted, '$0.10');
});

test('sliderIndexToGb maps index 5 to 10 GB and clamps bounds', () => {
  assert.equal(sliderIndexToGb(0), 1);
  assert.equal(sliderIndexToGb(5), 10);
  assert.equal(sliderIndexToGb(10), 100);
  assert.equal(sliderIndexToGb(99), 20480);
  assert.equal(formatGbDisplay(1024).unit, 'TB');
});

test('screenFileNames rejects dangerous scripts/executables and allows media/docs', () => {
  const safe = screenFileNames(['A001.mov', 'Wedding-Shoot/edit.mp4', 'archive.zip']);
  assert.equal(safe.allowed, true);
  assert.equal(safe.blockedFiles.length, 0);

  const unsafe = screenFileNames(['invoice.pdf', 'payload.exe', 'macro.docm']);
  assert.equal(unsafe.allowed, false);
  assert.deepEqual(unsafe.blockedFiles, ['payload.exe', 'macro.docm']);
});

test('transfer speed helpers compute, smooth, and format MB/s accurately', () => {
  assert.equal(calculateTransferSpeedMbps(10 * MB_BYTES, 1000), 10);
  assert.equal(calculateTransferSpeedMbps(5 * MB_BYTES, 2000), 2.5);
  assert.equal(calculateTransferSpeedMbps(0, 1000), 0);
  assert.equal(calculateTransferSpeedMbps(1000, 0), 0);

  const initial = smoothTransferSpeedMbps(null, 20 * MB_BYTES, 1000);
  assert.equal(initial, 20);
  const next = smoothTransferSpeedMbps(initial, 10 * MB_BYTES, 1000);
  assert.equal(Number(next.toFixed(2)), 16.5);

  assert.equal(formatTransferSpeedMbps(0), '0.0 MB/s');
  assert.equal(formatTransferSpeedMbps(0.05), '0.05 MB/s');
  assert.equal(formatTransferSpeedMbps(14.37), '14.4 MB/s');
  assert.equal(formatTransferSpeedMbps(142.8), '143 MB/s');
});
