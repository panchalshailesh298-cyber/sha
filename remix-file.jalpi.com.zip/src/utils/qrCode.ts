import QRCode from 'qrcode';

export interface GenerateQrOptions {
  size?: number;
}

export async function generateTransferQrCode(
  url: string,
  options: GenerateQrOptions = {}
): Promise<string> {
  const cleanUrl = url.trim();
  if (!cleanUrl) {
    throw new Error('A valid transfer URL is required to generate a QR code.');
  }

  const size = Math.max(128, options.size ?? 240);

  return QRCode.toDataURL(cleanUrl, {
    width: size,
    margin: 1,
    errorCorrectionLevel: 'M',
    color: {
      dark: '#0B1220',
      light: '#FFFFFF',
    },
  });
}
