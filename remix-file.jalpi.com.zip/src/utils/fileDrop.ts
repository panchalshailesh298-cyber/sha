export interface DroppedFileItem {
  file: File;
  relativePath: string;
}

interface WebKitEntryLike {
  isFile: boolean;
  isDirectory: boolean;
  name: string;
  file?: (success: (file: File) => void, error?: (err: unknown) => void) => void;
  createReader?: () => {
    readEntries: (success: (entries: WebKitEntryLike[]) => void, error?: (err: unknown) => void) => void;
  };
}

export function isFileDragEvent(dataTransfer: DataTransfer | null | undefined): boolean {
  if (!dataTransfer) return false;
  if (dataTransfer.types && Array.from(dataTransfer.types).includes('Files')) {
    return true;
  }
  return Boolean(dataTransfer.files && dataTransfer.files.length > 0);
}

async function readAllDirectoryEntries(entry: WebKitEntryLike): Promise<WebKitEntryLike[]> {
  const reader = entry.createReader?.();
  if (!reader) return [];
  const all: WebKitEntryLike[] = [];
  while (true) {
    const batch = await new Promise<WebKitEntryLike[]>((resolve) => {
      try {
        reader.readEntries(
          (entries) => resolve(entries),
          () => resolve([])
        );
      } catch {
        resolve([]);
      }
    });
    if (batch.length === 0) break;
    all.push(...batch);
  }
  return all;
}

async function traverseEntry(
  entry: WebKitEntryLike,
  parentPath = ''
): Promise<DroppedFileItem[]> {
  if (entry.isFile && entry.file) {
    const file = await new Promise<File | null>((resolve) => {
      try {
        entry.file!(
          (f) => resolve(f),
          () => resolve(null)
        );
      } catch {
        resolve(null);
      }
    });
    if (!file) return [];
    const relativePath = parentPath ? `${parentPath}/${file.name}` : file.name || 'file';
    return [{ file, relativePath }];
  }

  if (entry.isDirectory) {
    const dirPath = parentPath ? `${parentPath}/${entry.name}` : entry.name;
    const children = await readAllDirectoryEntries(entry);
    const nested: DroppedFileItem[] = [];
    for (const child of children) {
      nested.push(...(await traverseEntry(child, dirPath)));
    }
    return nested;
  }

  return [];
}

export async function extractDroppedFiles(
  dataTransfer: DataTransfer | null | undefined
): Promise<DroppedFileItem[]> {
  if (!dataTransfer) return [];

  const items = dataTransfer.items ? Array.from(dataTransfer.items) : [];
  if (items.length > 0) {
    const entries: WebKitEntryLike[] = [];
    for (const item of items) {
      const getEntry = (item as DataTransferItem & { webkitGetAsEntry?: () => WebKitEntryLike | null })
        .webkitGetAsEntry;
      const entry = typeof getEntry === 'function' ? getEntry.call(item) : null;
      if (entry) {
        entries.push(entry);
      }
    }

    if (entries.length > 0) {
      const collected: DroppedFileItem[] = [];
      for (const entry of entries) {
        collected.push(...(await traverseEntry(entry)));
      }
      if (collected.length > 0) {
        return collected;
      }
    }
  }

  const fileList = dataTransfer.files ? Array.from(dataTransfer.files) : [];
  return fileList
    .filter((file): file is File => Boolean(file))
    .map((file) => ({
      file,
      relativePath:
        (file as File & { webkitRelativePath?: string }).webkitRelativePath ||
        file.name ||
        'file',
    }));
}
