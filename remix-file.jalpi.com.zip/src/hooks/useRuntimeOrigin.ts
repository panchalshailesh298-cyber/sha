import { useCallback, useEffect, useState } from 'react';
import {
  deriveSharedAiStudioOrigin,
  getActiveAppOrigin,
  isPrivateAiStudioDevOrigin,
  setPublicAppOrigin,
} from '../utils/transferHistory';

export interface RuntimeOriginState {
  isPrivateDevPreview: boolean;
  currentOrigin: string;
  sharedOrigin: string | null;
  sharedOriginLive: boolean;
  checking: boolean;
}

const initialOrigin =
  typeof window !== 'undefined' && window.location?.origin
    ? window.location.origin.replace(/\/+$/, '')
    : 'http://localhost:3000';

let sharedState: RuntimeOriginState = {
  isPrivateDevPreview: isPrivateAiStudioDevOrigin(initialOrigin),
  currentOrigin: initialOrigin,
  sharedOrigin: deriveSharedAiStudioOrigin(initialOrigin),
  sharedOriginLive: false,
  checking: false,
};

let fetchedOnce = false;
let inflightProbe: Promise<void> | null = null;
const listeners = new Set<(next: RuntimeOriginState) => void>();

function publishState(next: RuntimeOriginState) {
  sharedState = next;
  if (next.sharedOriginLive && next.sharedOrigin) {
    setPublicAppOrigin(next.sharedOrigin);
  } else {
    setPublicAppOrigin(null);
  }
  listeners.forEach((listener) => listener(next));
}

async function fetchRuntimeOrigin(force = false): Promise<void> {
  if (inflightProbe && !force) return inflightProbe;
  fetchedOnce = true;

  const browserOrigin =
    typeof window !== 'undefined' && window.location?.origin
      ? window.location.origin.replace(/\/+$/, '')
      : sharedState.currentOrigin;

  publishState({
    ...sharedState,
    currentOrigin: browserOrigin,
    isPrivateDevPreview: isPrivateAiStudioDevOrigin(browserOrigin),
    sharedOrigin: deriveSharedAiStudioOrigin(browserOrigin) || sharedState.sharedOrigin,
    checking: true,
  });

  inflightProbe = (async () => {
    try {
      const res = await fetch(force ? '/api/runtime-info?force=1' : '/api/runtime-info', {
        cache: 'no-store',
      });
      if (!res.ok) {
        publishState({ ...sharedState, checking: false });
        return;
      }
      const data = (await res.json()) as {
        isPrivateDevPreview?: boolean;
        currentOrigin?: string;
        sharedOrigin?: string | null;
        sharedOriginLive?: boolean;
      };
      const resolvedBrowserPrivate = isPrivateAiStudioDevOrigin(browserOrigin);
      const isPrivateDevPreview =
        typeof window !== 'undefined'
          ? resolvedBrowserPrivate
          : Boolean(data.isPrivateDevPreview);
      const sharedOrigin =
        data.sharedOrigin || deriveSharedAiStudioOrigin(browserOrigin) || null;
      const sharedOriginLive = Boolean(data.sharedOriginLive && sharedOrigin);

      publishState({
        isPrivateDevPreview,
        currentOrigin: browserOrigin,
        sharedOrigin,
        sharedOriginLive,
        checking: false,
      });
    } catch {
      publishState({ ...sharedState, checking: false });
    } finally {
      inflightProbe = null;
    }
  })();

  return inflightProbe;
}

export function useRuntimeOrigin() {
  const [state, setState] = useState<RuntimeOriginState>(sharedState);

  useEffect(() => {
    listeners.add(setState);
    if (!fetchedOnce) {
      void fetchRuntimeOrigin(false);
    } else {
      setState(sharedState);
    }
    return () => {
      listeners.delete(setState);
    };
  }, []);

  const recheck = useCallback(() => {
    return fetchRuntimeOrigin(true);
  }, []);

  return {
    ...state,
    activeAppOrigin: getActiveAppOrigin(),
    recheck,
  };
}
