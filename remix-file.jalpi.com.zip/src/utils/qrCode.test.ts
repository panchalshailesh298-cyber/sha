import test from 'node:test';
import assert from 'node:assert/strict';
import { generateTransferQrCode } from './qrCode';

test('generateTransferQrCode returns a valid PNG data URL for transfer links', async () => {
  const dataUrl = await generateTransferQrCode('https://ais-pre-example.run.app/?t=3xZ6vm8g', {
    size: 192,
  });
  assert.ok(dataUrl.startsWith('data:image/png;base64,'));
  assert.ok(dataUrl.length > 100);
});

test('generateTransferQrCode rejects empty transfer URLs', async () => {
  await assert.rejects(() => generateTransferQrCode('   '), /valid transfer URL/i);
});
