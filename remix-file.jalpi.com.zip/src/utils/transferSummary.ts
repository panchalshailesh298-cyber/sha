import { formatBytes, TransferMode } from './transferMath';

export interface TransferSummaryFileItem {
  index?: number;
  name: string;
  relativePath?: string;
  size: number;
  uploaded?: boolean;
  virusScanStatus?: string;
}

export type ExpirationUrgency = 'nominal' | 'soon' | 'expired';

export interface ExpirationSummary {
  remainingLabel: string;
  exactDateLabel: string;
  windowLabel: string;
  urgency: ExpirationUrgency;
  remainingPercent: number;
}

export interface FileDetailsSummary {
  fileCount: number;
  totalBytes: number;
  summaryLabel: string;
  visibleFiles: Array<{
    key: string;
    displayName: string;
    sizeLabel: string;
    statusLabel: string;
  }>;
  hiddenCount: number;
}

export function formatExpirationIndicator(
  expiresAtIso: string,
  mode: TransferMode,
  nowMs: number = Date.now()
): ExpirationSummary {
  const expiresMs = Date.parse(expiresAtIso);
  const windowHours = mode === 'server' ? 24 * 7 : 24;
  const totalWindowMs = windowHours * 60 * 60 * 1000;
  const windowLabel = mode === 'server' ? '7-day vault window' : '24-hour direct window';

  if (!Number.isFinite(expiresMs)) {
    return {
      remainingLabel: mode === 'server' ? '7d 0h remaining' : '24h 0m remaining',
      exactDateLabel: mode === 'server' ? 'Active for 7 days' : 'Active for 24 hours',
      windowLabel,
      urgency: mode === 'server' ? 'nominal' : 'soon',
      remainingPercent: 100,
    };
  }

  const exactDateLabel = new Intl.DateTimeFormat('en-US', {
    month: 'short',
    day: 'numeric',
    hour: 'numeric',
    minute: '2-digit',
  }).format(new Date(expiresMs));

  const diffMs = expiresMs - nowMs;
  if (diffMs <= 0) {
    return {
      remainingLabel: 'Expired',
      exactDateLabel: `Expired ${exactDateLabel}`,
      windowLabel,
      urgency: 'expired',
      remainingPercent: 0,
    };
  }

  const totalMinutes = Math.max(1, Math.floor(diffMs / (60 * 1000)));
  const days = Math.floor(totalMinutes / (60 * 24));
  const hours = Math.floor((totalMinutes % (60 * 24)) / 60);
  const minutes = totalMinutes % 60;

  let remainingLabel: string;
  if (days >= 1) {
    remainingLabel = `${days}d ${hours}h remaining`;
  } else if (hours >= 1) {
    remainingLabel = `${hours}h ${minutes}m remaining`;
  } else {
    remainingLabel = `${minutes}m remaining`;
  }

  const remainingPercent = Math.max(4, Math.min(100, Math.round((diffMs / totalWindowMs) * 100)));
  const sixHoursMs = 6 * 60 * 60 * 1000;
  const urgency: ExpirationUrgency = diffMs <= sixHoursMs ? 'soon' : 'nominal';

  return {
    remainingLabel,
    exactDateLabel: `Expires ${exactDateLabel}`,
    windowLabel,
    urgency,
    remainingPercent,
  };
}

export function summarizeTransferFiles(
  files: TransferSummaryFileItem[],
  mode: TransferMode,
  showAll: boolean = false,
  maxPreviewCount: number = 4
): FileDetailsSummary {
  const safeFiles = Array.isArray(files) ? files : [];
  const totalBytes = safeFiles.reduce((sum, f) => sum + (Number.isFinite(f.size) ? Math.max(0, f.size) : 0), 0);
  const fileCount = safeFiles.length;
  const limit = showAll ? fileCount : Math.max(1, maxPreviewCount);
  const slice = safeFiles.slice(0, limit);

  const visibleFiles = slice.map((item, idx) => {
    const displayName = (item.relativePath || item.name || `file-${idx + 1}`).trim();
    const statusLabel =
      mode === 'server'
        ? item.virusScanStatus === 'clean'
          ? 'Screened'
          : 'Stored'
        : 'Delivered';
    return {
      key: `${item.index ?? idx}-${displayName}`,
      displayName,
      sizeLabel: formatBytes(item.size),
      statusLabel,
    };
  });

  return {
    fileCount,
    totalBytes,
    summaryLabel: `${fileCount} ${fileCount === 1 ? 'file' : 'files'} · ${formatBytes(totalBytes)}`,
    visibleFiles,
    hiddenCount: Math.max(0, fileCount - visibleFiles.length),
  };
}
