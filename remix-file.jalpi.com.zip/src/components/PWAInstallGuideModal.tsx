import React, { useEffect, useState } from 'react';
import {
  ArrowRight,
  Check,
  Copy,
  Download,
  ExternalLink,
  MoreVertical,
  PlusSquare,
  Share,
  Smartphone,
  X,
} from 'lucide-react';
import { usePWAInstall } from '../hooks/usePWAInstall';
import { copyToClipboard } from '../utils/clipboard';
import { TransferQrCode } from './TransferQrCode';

export const OPEN_PWA_GUIDE_EVENT = 'jalpi:open-pwa-guide';

export function openPWAInstallGuide() {
  if (typeof window !== 'undefined') {
    window.dispatchEvent(new CustomEvent(OPEN_PWA_GUIDE_EVENT));
  }
}

export function PWAInstallGuideModal() {
  const { isInstallable, isIOS, isAndroid, isInIframe, appUrl, install } = usePWAInstall();
  const [open, setOpen] = useState(false);
  const [copiedUrl, setCopiedUrl] = useState(false);

  useEffect(() => {
    const handleOpen = () => setOpen(true);
    window.addEventListener(OPEN_PWA_GUIDE_EVENT, handleOpen);
    return () => window.removeEventListener(OPEN_PWA_GUIDE_EVENT, handleOpen);
  }, []);

  if (!open) return null;

  const handleCopyUrl = async () => {
    const ok = await copyToClipboard(appUrl);
    if (ok) {
      setCopiedUrl(true);
      window.setTimeout(() => setCopiedUrl(false), 2000);
    }
  };

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-label="Installable Phone App"
      className="fixed inset-0 z-50 flex items-end sm:items-center justify-center bg-slate-950/60 p-0 sm:p-4 backdrop-blur-xs"
    >
      <div className="w-full sm:max-w-[490px] max-h-[90vh] overflow-y-auto rounded-t-3xl sm:rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-5 sm:p-6 shadow-2xl space-y-4">
        <div className="mx-auto h-1.5 w-10 rounded-full bg-slate-200 dark:bg-slate-700 sm:hidden" />

        <div className="flex items-start justify-between gap-3">
          <div className="flex items-start gap-3">
            <span className="brand-primary-bg mt-0.5 inline-flex h-10 w-10 shrink-0 items-center justify-center rounded-xl text-white shadow-xs">
              <Smartphone className="h-5 w-5" />
            </span>
            <div>
              <h3 className="font-display text-[18px] font-bold text-slate-900 dark:text-slate-50">
                Installable Phone App
              </h3>
              <p className="mt-0.5 text-[13px] text-slate-500 dark:text-slate-400">
                Add Share by Jalpi to your Home Screen on iOS or Android for full-screen mobile use.
              </p>
            </div>
          </div>
          <button
            type="button"
            aria-label="Close install guide"
            onClick={() => setOpen(false)}
            className="inline-flex h-10 w-10 shrink-0 items-center justify-center rounded-full border border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-slate-800 cursor-pointer"
          >
            <X className="h-4 w-4" />
          </button>
        </div>

        {isInstallable && (
          <button
            type="button"
            onClick={() => void install()}
            className="brand-cta flex w-full items-center justify-center gap-2 rounded-xl py-3 text-[14px] font-semibold text-white cursor-pointer min-h-[44px]"
          >
            <Download className="h-4 w-4" />
            <span>Install app now</span>
          </button>
        )}

        {isInIframe && (
          <div className="rounded-xl border border-blue-200 dark:border-blue-800/70 bg-blue-50/80 dark:bg-blue-950/40 p-3.5 text-[12.5px] text-blue-900 dark:text-blue-100 space-y-2">
            <p className="font-semibold">
              Embedded preview blocks 1-tap browser install prompts.
            </p>
            <p className="text-blue-800/90 dark:text-blue-200/90">
              Open this URL in a standalone Safari or Chrome tab to see the native install prompt.
            </p>
            <a
              href={appUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-1.5 font-semibold text-blue-700 dark:text-blue-300 underline underline-offset-2"
            >
              <span>Open in browser tab</span>
              <ExternalLink className="h-3.5 w-3.5" />
            </a>
          </div>
        )}

        <div className="rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50/80 dark:bg-slate-950/60 p-4 flex flex-col sm:flex-row items-center gap-4">
          <TransferQrCode
            url={appUrl}
            size={122}
            alt="QR code to open Share by Jalpi on your phone"
          />

          <div className="w-full min-w-0 flex-1 space-y-2.5 text-center sm:text-left">
            <div>
              <div className="text-[11px] font-semibold uppercase tracking-wider text-slate-500 dark:text-slate-400">
                Scan on phone or copy URL
              </div>
              <div className="mt-1 truncate rounded-lg border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 px-2.5 py-1.5 font-mono text-[11.5px] text-slate-700 dark:text-slate-300">
                {appUrl}
              </div>
            </div>

            <div className="flex flex-wrap items-center justify-center sm:justify-start gap-2">
              <button
                type="button"
                onClick={() => void handleCopyUrl()}
                className="inline-flex items-center gap-1.5 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 px-3 py-2 text-[12.5px] font-semibold text-slate-800 dark:text-slate-100 hover:border-blue-600 cursor-pointer min-h-[38px]"
              >
                {copiedUrl ? (
                  <Check className="h-3.5 w-3.5 text-emerald-600" />
                ) : (
                  <Copy className="h-3.5 w-3.5 text-blue-600 dark:text-blue-400" />
                )}
                <span>{copiedUrl ? 'Copied link' : 'Copy app URL'}</span>
              </button>

              <a
                href={appUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-1.5 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 px-3 py-2 text-[12.5px] font-semibold text-slate-800 dark:text-slate-100 hover:border-blue-600 min-h-[38px]"
              >
                <ExternalLink className="h-3.5 w-3.5 text-blue-600 dark:text-blue-400" />
                <span>Open tab</span>
              </a>
            </div>
          </div>
        </div>

        <div className="grid grid-cols-1 gap-3 text-[13px] text-slate-600 dark:text-slate-300">
          {/* iOS Safari */}
          <div
            className={`rounded-xl border p-3.5 space-y-2.5 ${
              isIOS
                ? 'border-blue-400 dark:border-blue-600 bg-blue-50/40 dark:bg-blue-950/25'
                : 'border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900'
            }`}
          >
            <div className="flex items-center justify-between gap-2">
              <span className="font-semibold text-slate-900 dark:text-slate-100">
                iOS · Safari
              </span>
              <span className="inline-flex items-center gap-1.5 text-[11.5px] font-medium text-blue-700 dark:text-blue-300">
                <Share className="h-3.5 w-3.5" aria-hidden="true" />
                <span>Share</span>
                <ArrowRight className="h-3 w-3 opacity-60" aria-hidden="true" />
                <PlusSquare className="h-3.5 w-3.5" aria-hidden="true" />
                <span>Add to Home Screen</span>
              </span>
            </div>
            <ol className="space-y-1.5 text-[12.5px] leading-relaxed">
              <li className="flex items-center gap-2">
                <span className="inline-flex h-5 w-5 shrink-0 items-center justify-center rounded-md bg-slate-100 dark:bg-slate-800 text-[11px] font-bold text-slate-700 dark:text-slate-200">
                  1
                </span>
                <span>Open the URL above in Safari on your iPhone or iPad.</span>
              </li>
              <li className="flex items-center gap-2">
                <span className="inline-flex h-5 w-5 shrink-0 items-center justify-center rounded-md bg-blue-50 dark:bg-blue-950 text-blue-700 dark:text-blue-300">
                  <Share className="h-3.5 w-3.5" aria-hidden="true" />
                </span>
                <span>
                  Tap the <strong className="text-slate-900 dark:text-white">Share icon</strong> in
                  Safari&apos;s toolbar.
                </span>
              </li>
              <li className="flex items-center gap-2">
                <span className="inline-flex h-5 w-5 shrink-0 items-center justify-center rounded-md bg-blue-50 dark:bg-blue-950 text-blue-700 dark:text-blue-300">
                  <PlusSquare className="h-3.5 w-3.5" aria-hidden="true" />
                </span>
                <span>
                  Scroll down and tap{' '}
                  <strong className="text-slate-900 dark:text-white">Add to Home Screen</strong>.
                </span>
              </li>
            </ol>
          </div>

          {/* Android Chrome */}
          <div
            className={`rounded-xl border p-3.5 space-y-2.5 ${
              isAndroid
                ? 'border-blue-400 dark:border-blue-600 bg-blue-50/40 dark:bg-blue-950/25'
                : 'border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900'
            }`}
          >
            <div className="flex items-center justify-between gap-2">
              <span className="font-semibold text-slate-900 dark:text-slate-100">
                Android · Chrome
              </span>
              <span className="inline-flex items-center gap-1.5 text-[11.5px] font-medium text-blue-700 dark:text-blue-300">
                <MoreVertical className="h-3.5 w-3.5" aria-hidden="true" />
                <span>Three dots</span>
                <ArrowRight className="h-3 w-3 opacity-60" aria-hidden="true" />
                <Download className="h-3.5 w-3.5" aria-hidden="true" />
                <span>Install app</span>
              </span>
            </div>
            <ol className="space-y-1.5 text-[12.5px] leading-relaxed">
              <li className="flex items-center gap-2">
                <span className="inline-flex h-5 w-5 shrink-0 items-center justify-center rounded-md bg-slate-100 dark:bg-slate-800 text-[11px] font-bold text-slate-700 dark:text-slate-200">
                  1
                </span>
                <span>Open the URL above in Chrome on Android.</span>
              </li>
              <li className="flex items-center gap-2">
                <span className="inline-flex h-5 w-5 shrink-0 items-center justify-center rounded-md bg-blue-50 dark:bg-blue-950 text-blue-700 dark:text-blue-300">
                  <MoreVertical className="h-3.5 w-3.5" aria-hidden="true" />
                </span>
                <span>
                  Tap the <strong className="text-slate-900 dark:text-white">Three dots</strong>{' '}
                  menu icon in the top right.
                </span>
              </li>
              <li className="flex items-center gap-2">
                <span className="inline-flex h-5 w-5 shrink-0 items-center justify-center rounded-md bg-blue-50 dark:bg-blue-950 text-blue-700 dark:text-blue-300">
                  <Download className="h-3.5 w-3.5" aria-hidden="true" />
                </span>
                <span>
                  Tap <strong className="text-slate-900 dark:text-white">Install app</strong> (or{' '}
                  <strong className="text-slate-900 dark:text-white">Add to Home screen</strong>).
                </span>
              </li>
            </ol>
          </div>
        </div>

        <button
          type="button"
          onClick={() => setOpen(false)}
          className="w-full rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 py-2.5 text-[13.5px] font-semibold text-slate-800 dark:text-slate-100 hover:bg-slate-100 dark:hover:bg-slate-700 cursor-pointer min-h-[44px]"
        >
          Done
        </button>
      </div>
    </div>
  );
}
