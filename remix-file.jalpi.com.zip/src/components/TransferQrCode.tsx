import React, { useEffect, useState } from 'react';
import { generateTransferQrCode } from '../utils/qrCode';

interface TransferQrCodeProps {
  url: string;
  alt?: string;
  size?: number;
  className?: string;
}

export function TransferQrCode({
  url,
  alt = 'QR code to open transfer on your phone',
  size = 132,
  className = '',
}: TransferQrCodeProps) {
  const [qrDataUrl, setQrDataUrl] = useState<string>('');

  useEffect(() => {
    if (!url.trim()) {
      setQrDataUrl('');
      return;
    }

    let active = true;
    generateTransferQrCode(url, { size: Math.max(128, size * 2) })
      .then((dataUrl) => {
        if (active) setQrDataUrl(dataUrl);
      })
      .catch(() => {
        if (active) setQrDataUrl('');
      });

    return () => {
      active = false;
    };
  }, [url, size]);

  return (
    <div
      className={`shrink-0 rounded-xl border border-slate-200 dark:border-slate-700 bg-white p-1.5 shadow-xs ${className}`}
      style={{ width: size + 14, height: size + 14 }}
    >
      {qrDataUrl ? (
        <img
          src={qrDataUrl}
          alt={alt}
          width={size}
          height={size}
          className="block h-full w-full rounded-md"
        />
      ) : (
        <div className="flex h-full w-full items-center justify-center text-[11px] font-mono text-slate-400">
          QR…
        </div>
      )}
    </div>
  );
}
