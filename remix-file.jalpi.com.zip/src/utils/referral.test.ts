import test from 'node:test';
import assert from 'node:assert/strict';
import {
  buildReferralLink,
  buildSafeReferralLabel,
  generateReferralCode,
  normalizeReferralCode,
  parseReferralCodeFromSearch,
  ReferralRecord,
  summarizeReferrals,
} from './referral';

test('normalizeReferralCode and parseReferralCodeFromSearch validate referral query params safely', () => {
  assert.equal(normalizeReferralCode('  ALEX8K2P  '), 'ALEX8K2P');
  assert.equal(normalizeReferralCode('ab'), null);
  assert.equal(normalizeReferralCode('bad$code!'), null);
  assert.equal(parseReferralCodeFromSearch('?ref=JLP92M4X'), 'JLP92M4X');
  assert.equal(parseReferralCodeFromSearch('?t=abc123&ref=TEAM_01'), 'TEAM_01');
  assert.equal(parseReferralCodeFromSearch('?ref=bad'), null);
});

test('generateReferralCode and buildReferralLink produce valid shareable referral URLs', () => {
  const code = generateReferralCode('u19xAbC');
  assert.equal(code.length, 8);
  assert.ok(normalizeReferralCode(code) !== null);
  assert.equal(
    buildReferralLink('https://share.jalpi.com/', code),
    `https://share.jalpi.com/?ref=${code}`
  );
});

test('buildSafeReferralLabel strips raw email and phone PII', () => {
  assert.equal(buildSafeReferralLabel({ displayName: 'Ananya Sharma' }), 'Ananya S.');
  assert.equal(buildSafeReferralLabel({ displayName: 'Vikram' }), 'Vikram');
  assert.equal(
    buildSafeReferralLabel({ displayName: 'secret@example.com', email: 'secret@example.com' }),
    'Google Member'
  );
  assert.equal(
    buildSafeReferralLabel({ displayName: '+919876543210', phoneNumber: '+919876543210' }),
    'Phone Member'
  );
});

test('summarizeReferrals computes available balance, joined count, and earned GB accurately', () => {
  const records: ReferralRecord[] = [
    {
      referredUid: 'u2',
      referredLabel: 'Riya K.',
      referrerUid: 'u1',
      referralCode: 'U1REF123',
      creditGb: 1,
      referrerClaimed: true,
      referredClaimed: true,
      createdAtMs: 1000,
    },
    {
      referredUid: 'u3',
      referredLabel: 'Dev M.',
      referrerUid: 'u1',
      referralCode: 'U1REF123',
      creditGb: 1,
      referrerClaimed: false,
      referredClaimed: true,
      createdAtMs: 2000,
    },
  ];

  const summary = summarizeReferrals(records, 2, true);
  assert.equal(summary.availableCreditGb, 2);
  assert.equal(summary.friendsJoined, 2);
  assert.equal(summary.pendingClaims, 1);
  assert.equal(summary.totalEarnedGb, 2);
});
