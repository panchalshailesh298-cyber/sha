import test from 'node:test';
import assert from 'node:assert/strict';
import { formatExpirationIndicator, summarizeTransferFiles } from './transferSummary';

test('formatExpirationIndicator formats multi-day vault expiry cleanly', () => {
  const now = Date.UTC(2026, 10, 20, 12, 0, 0);
  const expiresAt = new Date(now + (6 * 24 + 23) * 60 * 60 * 1000).toISOString();
  const result = formatExpirationIndicator(expiresAt, 'server', now);

  assert.equal(result.remainingLabel, '6d 23h remaining');
  assert.equal(result.urgency, 'nominal');
  assert.equal(result.windowLabel, '7-day vault window');
  assert.match(result.exactDateLabel, /^Expires /);
  assert.ok(result.remainingPercent >= 95 && result.remainingPercent <= 100);
});

test('formatExpirationIndicator flags transfers expiring within 6 hours as soon', () => {
  const now = Date.UTC(2026, 10, 20, 12, 0, 0);
  const expiresAt = new Date(now + 3 * 60 * 60 * 1000 + 20 * 60 * 1000).toISOString();
  const result = formatExpirationIndicator(expiresAt, 'p2p', now);

  assert.equal(result.remainingLabel, '3h 20m remaining');
  assert.equal(result.urgency, 'soon');
  assert.equal(result.windowLabel, '24-hour direct window');
});

test('formatExpirationIndicator handles expired timestamps cleanly', () => {
  const now = Date.UTC(2026, 10, 20, 12, 0, 0);
  const expiresAt = new Date(now - 60 * 1000).toISOString();
  const result = formatExpirationIndicator(expiresAt, 'server', now);

  assert.equal(result.remainingLabel, 'Expired');
  assert.equal(result.urgency, 'expired');
  assert.equal(result.remainingPercent, 0);
});

test('summarizeTransferFiles computes file counts, total bytes, and preview truncation', () => {
  const files = [
    { index: 0, name: 'clip1.mov', relativePath: 'Project/clip1.mov', size: 2048, virusScanStatus: 'clean' },
    { index: 1, name: 'clip2.mov', relativePath: 'Project/clip2.mov', size: 1024, virusScanStatus: 'clean' },
    { index: 2, name: 'clip3.mov', relativePath: 'Project/clip3.mov', size: 512, virusScanStatus: 'clean' },
    { index: 3, name: 'clip4.mov', relativePath: 'Project/clip4.mov', size: 512, virusScanStatus: 'clean' },
    { index: 4, name: 'notes.pdf', relativePath: 'notes.pdf', size: 1024, virusScanStatus: 'clean' },
  ];

  const compact = summarizeTransferFiles(files, 'server', false, 4);
  assert.equal(compact.fileCount, 5);
  assert.equal(compact.totalBytes, 5120);
  assert.equal(compact.summaryLabel, '5 files · 5 KB');
  assert.equal(compact.visibleFiles.length, 4);
  assert.equal(compact.hiddenCount, 1);
  assert.equal(compact.visibleFiles[0].statusLabel, 'Screened');

  const expanded = summarizeTransferFiles(files, 'p2p', true, 4);
  assert.equal(expanded.visibleFiles.length, 5);
  assert.equal(expanded.hiddenCount, 0);
  assert.equal(expanded.visibleFiles[4].statusLabel, 'Delivered');
});
