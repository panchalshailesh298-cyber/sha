import React, { useCallback, useEffect, useRef, useState } from 'react';
import { onAuthStateChanged } from 'firebase/auth';
import { CreditCard, Folder, Gift, Lock, RefreshCw, Upload, X } from 'lucide-react';
import { AccountModal, AccountModalTab, AccountUser, LegalModal } from './components/AccountModal';
import { Header } from './components/Header';
import { LandingSections } from './components/LandingSections';
import { MobileBottomNav, MobileNavTab } from './components/MobileBottomNav';
import { PricingAndBottom } from './components/PricingAndBottom';
import {
  OfflineIndicator,
  openPWAInstallGuide,
  PWAInstallButton,
  PWAInstallGuideModal,
} from './components/PWAInstallButton';
import { ReceiverView } from './components/ReceiverView';
import { SendWorkbench } from './components/SendWorkbench';
import { TransferToastContainer } from './components/TransferToastContainer';
import {
  addSavedPaymentMethod,
  auth,
  claimReferralReward,
  createPhoneRecaptcha,
  deleteSavedPaymentMethod,
  deleteTransferHistoryRecord,
  ensureUserProfile,
  formatFirebaseAuthError,
  SaveTransferHistoryInput,
  saveTransferToHistory,
  sendPhoneOtp,
  setDefaultPaymentMethod,
  signInWithGoogle,
  signOutUser,
  subscribeToPaymentMethods,
  subscribeToReferrals,
  subscribeToTransferHistory,
  subscribeToUserProfile,
  updateTransferHistoryStatus,
} from './firebase';
import {
  normalizeReferralCode,
  parseReferralCodeFromSearch,
  ReferralRecord,
  UserReferralProfile,
} from './utils/referral';
import { Currency } from './utils/transferMath';
import {
  buildTransferShareUrl,
  PaymentMethod,
  PaymentRegion,
  resolvePaymentSelection,
  SavedPaymentMethod,
  TransferHistoryEntry,
  TransferLifecycleStatus,
} from './utils/transferHistory';
import {
  ActiveTransferToast,
  dismissTransferToast,
  getVisibleTransferToasts,
  removeTransferToast,
  reopenAllTransferToasts,
  upsertTransferToast,
} from './utils/transferToasts';
import { DroppedFileItem, extractDroppedFiles, isFileDragEvent } from './utils/fileDrop';
import { useRuntimeOrigin } from './hooks/useRuntimeOrigin';

const PENDING_REFERRAL_STORAGE_KEY = 'jalpishare_pending_ref';

function stripRefFromCurrentUrl() {
  try {
    const url = new URL(window.location.href);
    if (url.searchParams.has('ref')) {
      url.searchParams.delete('ref');
      const nextSearch = url.searchParams.toString();
      const nextUrl = `${url.pathname}${nextSearch ? `?${nextSearch}` : ''}${url.hash}`;
      window.history.replaceState({}, '', nextUrl);
    }
  } catch {
    // Ignore history errors
  }
}

export default function App() {
  useRuntimeOrigin();
  const [currency, setCurrency] = useState<Currency>('USD');
  const [darkMode, setDarkMode] = useState<boolean>(() => {
    try {
      const saved = window.localStorage.getItem('jalpishare_theme');
      if (saved === 'dark') return true;
      if (saved === 'light') return false;
      return window.matchMedia?.('(prefers-color-scheme: dark)').matches ?? false;
    } catch {
      return false;
    }
  });

  const [authUser, setAuthUser] = useState<AccountUser | null>(null);
  const [authReady, setAuthReady] = useState(false);

  const [historyEntries, setHistoryEntries] = useState<TransferHistoryEntry[]>([]);
  const [historyLoading, setHistoryLoading] = useState(false);
  const [historyError, setHistoryError] = useState<string | null>(null);

  const [paymentMethods, setPaymentMethods] = useState<SavedPaymentMethod[]>([]);
  const [paymentsLoading, setPaymentsLoading] = useState(false);
  const [paymentsError, setPaymentsError] = useState<string | null>(null);

  const [pendingReferralCode, setPendingReferralCode] = useState<string | null>(() => {
    const fromSearch = parseReferralCodeFromSearch(window.location.search);
    if (fromSearch) {
      try {
        window.localStorage.setItem(PENDING_REFERRAL_STORAGE_KEY, fromSearch);
      } catch {
        // Ignore storage errors
      }
      return fromSearch;
    }
    try {
      return normalizeReferralCode(window.localStorage.getItem(PENDING_REFERRAL_STORAGE_KEY));
    } catch {
      return null;
    }
  });
  const pendingReferralRef = useRef<string | null>(pendingReferralCode);
  useEffect(() => {
    pendingReferralRef.current = pendingReferralCode;
  }, [pendingReferralCode]);

  const currencyRef = useRef<Currency>(currency);
  useEffect(() => {
    currencyRef.current = currency;
  }, [currency]);

  const [referralProfile, setReferralProfile] = useState<UserReferralProfile | null>(null);
  const [profileError, setProfileError] = useState<string | null>(null);
  const [referrals, setReferrals] = useState<ReferralRecord[]>([]);
  const [referralsLoading, setReferralsLoading] = useState(false);
  const [referralsError, setReferralsError] = useState<string | null>(null);
  const claimingReferralsRef = useRef<Set<string>>(new Set());
  const claimingInFlightRef = useRef(false);
  const [claimTick, setClaimTick] = useState(0);

  const [workbenchMode, setWorkbenchMode] = useState<'demo' | 'send'>('demo');
  const [workbenchMinimized, setWorkbenchMinimized] = useState(false);
  const [transferToasts, setTransferToasts] = useState<ActiveTransferToast[]>([]);
  const [pickerSignal, setPickerSignal] = useState(0);
  const [heroDragging, setHeroDragging] = useState(false);
  const heroDragDepthRef = useRef(0);
  const [heroDroppedBatch, setHeroDroppedBatch] = useState<{
    id: number;
    files: DroppedFileItem[];
  } | null>(null);

  const [authModalOpen, setAuthModalOpen] = useState(false);
  const [accountModalTab, setAccountModalTab] = useState<AccountModalTab>('transfers');
  const [mobileNavTab, setMobileNavTab] = useState<MobileNavTab>('send');
  const [legalDoc, setLegalDoc] = useState<'privacy' | 'terms' | 'refunds' | null>(null);

  const [receiverCode, setReceiverCode] = useState<string | null>(() => {
    const params = new URLSearchParams(window.location.search);
    const tParam = params.get('t');
    if (tParam) return tParam;
    const match = window.location.pathname.match(/^\/t\/([A-Za-z0-9_-]+)/);
    return match ? match[1] : null;
  });

  useEffect(() => {
    document.documentElement.classList.toggle('dark', darkMode);
    try {
      window.localStorage.setItem('jalpishare_theme', darkMode ? 'dark' : 'light');
    } catch {
      // Ignore storage errors
    }
  }, [darkMode]);

  const clearPendingReferral = useCallback(() => {
    setPendingReferralCode(null);
    pendingReferralRef.current = null;
    try {
      window.localStorage.removeItem(PENDING_REFERRAL_STORAGE_KEY);
    } catch {
      // Ignore storage errors
    }
    stripRefFromCurrentUrl();
  }, []);

  const syncCurrentUserProfile = useCallback(async () => {
    const fbUser = auth.currentUser;
    if (!fbUser) return;
    setProfileError(null);
    try {
      await ensureUserProfile(fbUser, currencyRef.current, pendingReferralRef.current);
      clearPendingReferral();
    } catch (err) {
      const msg = err instanceof Error ? err.message : 'Unable to sync account profile.';
      setProfileError(msg);
      console.error('Failed to sync user profile:', err);
    }
  }, [clearPendingReferral]);

  useEffect(() => {
    const unsub = onAuthStateChanged(auth, async (fbUser) => {
      if (fbUser) {
        const mapped: AccountUser = {
          uid: fbUser.uid,
          email: fbUser.email,
          phoneNumber: fbUser.phoneNumber,
          displayName: fbUser.displayName,
          photoURL: fbUser.photoURL,
          providerId: fbUser.providerData?.[0]?.providerId,
        };
        setAuthUser(mapped);
        setAuthReady(true);
        await syncCurrentUserProfile();
      } else {
        setAuthUser(null);
        setHistoryEntries([]);
        setHistoryLoading(false);
        setHistoryError(null);
        setPaymentMethods([]);
        setPaymentsLoading(false);
        setPaymentsError(null);
        setReferralProfile(null);
        setProfileError(null);
        setReferrals([]);
        setReferralsLoading(false);
        setReferralsError(null);
        claimingReferralsRef.current.clear();
        claimingInFlightRef.current = false;
        setAuthReady(true);
      }
    });
    return () => unsub();
  }, [syncCurrentUserProfile]);

  useEffect(() => {
    if (!authReady || !authUser) return;
    setHistoryLoading(true);
    setHistoryError(null);
    const unsub = subscribeToTransferHistory(
      authUser.uid,
      (entries) => {
        setHistoryEntries(entries);
        setHistoryLoading(false);
      },
      (err) => {
        setHistoryError(err.message);
        setHistoryLoading(false);
      }
    );
    return () => unsub();
  }, [authReady, authUser]);

  useEffect(() => {
    if (!authReady || !authUser) return;
    setPaymentsLoading(true);
    setPaymentsError(null);
    const unsub = subscribeToPaymentMethods(
      authUser.uid,
      (methods) => {
        setPaymentMethods(methods);
        setPaymentsLoading(false);
      },
      (err) => {
        setPaymentsError(err.message);
        setPaymentsLoading(false);
      }
    );
    return () => unsub();
  }, [authReady, authUser]);

  useEffect(() => {
    if (!authReady || !authUser) return;
    const unsub = subscribeToUserProfile(
      authUser.uid,
      (profile) => {
        setReferralProfile(profile);
        if (profile) setProfileError(null);
      },
      (err) => {
        setProfileError(err.message);
        console.error('Failed to subscribe to user profile:', err);
      }
    );
    return () => unsub();
  }, [authReady, authUser]);

  useEffect(() => {
    if (!authReady || !authUser) return;
    setReferralsLoading(true);
    setReferralsError(null);
    const unsub = subscribeToReferrals(
      authUser.uid,
      (items) => {
        setReferrals(items);
        setReferralsLoading(false);
      },
      (err) => {
        setReferralsError(err.message);
        setReferralsLoading(false);
      }
    );
    return () => unsub();
  }, [authReady, authUser]);

  useEffect(() => {
    if (!authUser || !referralProfile || claimingInFlightRef.current) return;
    const nextUnclaimed = referrals.find(
      (r) => !r.referrerClaimed && !claimingReferralsRef.current.has(r.referredUid)
    );
    if (!nextUnclaimed) return;

    claimingInFlightRef.current = true;
    claimingReferralsRef.current.add(nextUnclaimed.referredUid);

    void claimReferralReward(authUser.uid, nextUnclaimed.referredUid)
      .catch((err) => {
        claimingReferralsRef.current.delete(nextUnclaimed.referredUid);
        console.error('Failed to claim referral reward:', err);
      })
      .finally(() => {
        claimingInFlightRef.current = false;
        setClaimTick((t) => t + 1);
      });
  }, [authUser, referralProfile, referrals, claimTick]);

  useEffect(() => {
    const onPop = () => {
      const fromSearch = parseReferralCodeFromSearch(window.location.search);
      if (fromSearch) {
        setPendingReferralCode(fromSearch);
        try {
          window.localStorage.setItem(PENDING_REFERRAL_STORAGE_KEY, fromSearch);
        } catch {
          // Ignore storage errors
        }
      }
      const params = new URLSearchParams(window.location.search);
      const tParam = params.get('t');
      if (tParam) {
        setReceiverCode(tParam);
        return;
      }
      const match = window.location.pathname.match(/^\/t\/([A-Za-z0-9_-]+)/);
      setReceiverCode(match ? match[1] : null);
    };
    window.addEventListener('popstate', onPop);
    return () => window.removeEventListener('popstate', onPop);
  }, []);

  const handleOpenAuth = useCallback((tab: AccountModalTab = 'transfers') => {
    setAccountModalTab(tab);
    setAuthModalOpen(true);
  }, []);

  const handleGoogleSignIn = async () => {
    await signInWithGoogle();
  };

  const handleLogout = async () => {
    await signOutUser();
  };

  const handleAddPaymentMethod = useCallback(
    async (input: {
      label: string;
      region: PaymentRegion;
      method: PaymentMethod;
      detail: string;
      isDefault: boolean;
    }) => {
      if (!authUser) throw new Error('Sign in to save payment methods.');
      const selection = resolvePaymentSelection(input.region, input.method);
      await addSavedPaymentMethod(
        authUser.uid,
        {
          label: input.label,
          region: selection.region,
          gateway: selection.gateway,
          method: selection.method,
          detail: input.detail,
          isDefault: input.isDefault,
        },
        paymentMethods
      );
    },
    [authUser, paymentMethods]
  );

  const handleSetDefaultPaymentMethod = useCallback(
    async (id: string) => {
      if (!authUser) return;
      await setDefaultPaymentMethod(authUser.uid, id, paymentMethods);
    },
    [authUser, paymentMethods]
  );

  const handleDeletePaymentMethod = useCallback(
    async (id: string) => {
      if (!authUser) return;
      await deleteSavedPaymentMethod(authUser.uid, id);
    },
    [authUser]
  );

  const handleTransferRecorded = useCallback(
    (entry: SaveTransferHistoryInput) => {
      if (!authUser) return;
      const normalizedEntry: SaveTransferHistoryInput = {
        ...entry,
        shareUrl: buildTransferShareUrl(entry.code),
      };
      void saveTransferToHistory(authUser.uid, normalizedEntry).catch((err) => {
        console.error('Failed to persist transfer history:', err);
      });
    },
    [authUser]
  );

  const handleTransferStatusSync = useCallback(
    (code: string, status: TransferLifecycleStatus) => {
      if (!authUser) return;
      void updateTransferHistoryStatus(authUser.uid, code, status).catch((err) => {
        console.error('Failed to sync transfer status:', err);
      });
    },
    [authUser]
  );

  const handleDeleteHistoryEntry = useCallback(
    async (code: string) => {
      await fetch(`/api/transfers/${code}`, { method: 'DELETE' }).catch(() => {});
      if (authUser) {
        await deleteTransferHistoryRecord(authUser.uid, code);
      }
    },
    [authUser]
  );

  const handleTransferToastUpdate = useCallback((toast: ActiveTransferToast) => {
    const normalizedToast: ActiveTransferToast = {
      ...toast,
      shareUrl: toast.shareUrl || buildTransferShareUrl(toast.code),
    };
    setTransferToasts((prev) => upsertTransferToast(prev, normalizedToast));
  }, []);

  const handleTransferToastRemove = useCallback((code: string) => {
    setTransferToasts((prev) => removeTransferToast(prev, code));
  }, []);

  const handleMinimizeChange = useCallback((minimized: boolean) => {
    setWorkbenchMinimized(minimized);
    if (minimized) {
      setTransferToasts((prev) => reopenAllTransferToasts(prev));
    }
  }, []);

  const scrollToSend = useCallback((openPicker = false) => {
    setWorkbenchMode('send');
    setWorkbenchMinimized(false);
    setMobileNavTab('send');
    document.getElementById('send')?.scrollIntoView({ behavior: 'smooth', block: 'center' });
    if (openPicker) {
      setPickerSignal((s) => s + 1);
    }
  }, []);

  const handleMobileNavSelect = useCallback(
    (tab: MobileNavTab) => {
      setMobileNavTab(tab);
      if (tab === 'send') {
        if (receiverCode) {
          window.history.pushState({}, '', '/');
          setReceiverCode(null);
        }
        scrollToSend(false);
      } else if (tab === 'history') {
        handleOpenAuth('transfers');
      } else if (tab === 'payments') {
        handleOpenAuth('payments');
      } else {
        handleOpenAuth('transfers');
      }
    },
    [handleOpenAuth, receiverCode, scrollToSend]
  );

  const handleBackHome = () => {
    window.history.pushState({}, '', '/');
    setReceiverCode(null);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const userLabel = authUser?.email || authUser?.phoneNumber || null;

  const visibleToasts = getVisibleTransferToasts(
    transferToasts,
    workbenchMode === 'send' && workbenchMinimized
  );

  return (
    <div className="min-h-screen overflow-x-clip bg-[#F4F6FA] dark:bg-[#070B14] text-slate-900 dark:text-slate-100 pb-16 md:pb-0 transition-colors">
      <a
        href="#send"
        className="sr-only focus:not-sr-only focus:fixed focus:top-2 focus:left-2 focus:z-50 focus:rounded-lg focus:bg-blue-700 focus:px-3 focus:py-2 focus:text-white"
      >
        Skip to send files
      </a>

      <Header
        userLabel={userLabel}
        darkMode={darkMode}
        onToggleDarkMode={() => setDarkMode((d) => !d)}
        onOpenAuth={handleOpenAuth}
        onSendClick={() => scrollToSend(false)}
        isReceiverPage={Boolean(receiverCode)}
        onBackHome={handleBackHome}
      />

      {receiverCode ? (
        <ReceiverView code={receiverCode} onBackHome={handleBackHome} />
      ) : (
        <main>
          {/* Hero Section */}
          <section
            data-testid="landing-hero"
            onDragEnter={(e) => {
              if (!isFileDragEvent(e.dataTransfer)) return;
              e.preventDefault();
              heroDragDepthRef.current += 1;
              setHeroDragging(true);
            }}
            onDragOver={(e) => {
              if (!isFileDragEvent(e.dataTransfer)) return;
              e.preventDefault();
              e.dataTransfer.dropEffect = 'copy';
              setHeroDragging(true);
            }}
            onDragLeave={(e) => {
              if (!isFileDragEvent(e.dataTransfer)) return;
              e.preventDefault();
              heroDragDepthRef.current = Math.max(0, heroDragDepthRef.current - 1);
              if (heroDragDepthRef.current === 0) {
                setHeroDragging(false);
              }
            }}
            onDrop={async (e) => {
              if (!isFileDragEvent(e.dataTransfer)) return;
              e.preventDefault();
              heroDragDepthRef.current = 0;
              setHeroDragging(false);
              const items = await extractDroppedFiles(e.dataTransfer);
              if (items.length === 0) return;
              setWorkbenchMode('send');
              setWorkbenchMinimized(false);
              setHeroDroppedBatch((prev) => ({
                id: (prev?.id ?? 0) + 1,
                files: items,
              }));
            }}
            className="studio-grid-surface relative border-b border-slate-200 dark:border-slate-800"
          >
            {heroDragging && (
              <div
                data-testid="hero-drop-overlay"
                className="pointer-events-none absolute inset-0 z-30 flex items-center justify-center border-2 border-dashed border-blue-600 dark:border-blue-400 bg-blue-50/88 dark:bg-slate-950/88 backdrop-blur-[2px] p-6"
              >
                <div className="rounded-2xl border border-blue-200 dark:border-blue-800 bg-white dark:bg-slate-900 px-8 py-6 text-center shadow-2xl">
                  <div className="mx-auto mb-3 inline-flex h-12 w-12 items-center justify-center rounded-xl brand-primary-bg text-white">
                    <Upload className="h-5 w-5" />
                  </div>
                  <p className="font-display text-[20px] font-extrabold text-slate-900 dark:text-white">
                    Drop files or folders anywhere to upload
                  </p>
                  <p className="mt-1 text-[13.5px] text-slate-600 dark:text-slate-300">
                    Instant security screening · Direct P2P or 7-Day Vault
                  </p>
                </div>
              </div>
            )}
            <div className="mx-auto max-w-[1200px] px-5 sm:px-8 pt-10 pb-14 sm:pt-14 sm:pb-18 grid gap-10 lg:grid-cols-[1.06fr_0.94fr] items-center">
              {/* Left Hero Copy */}
              <div className="min-w-0">
                {!authUser && pendingReferralCode && (
                  <div
                    data-testid="referral-invite-banner"
                    className="mb-5 flex flex-wrap sm:flex-nowrap items-center justify-between gap-2.5 sm:gap-3 rounded-xl border border-blue-200 dark:border-blue-800/70 bg-blue-50/90 dark:bg-blue-950/50 px-3.5 py-2.5 text-left"
                  >
                    <div className="flex items-center gap-2.5 min-w-0">
                      <Gift className="h-4 w-4 shrink-0 text-blue-700 dark:text-blue-400" />
                      <p className="min-w-0 text-[12.5px] leading-snug text-slate-700 dark:text-slate-200">
                        <span className="font-semibold text-slate-900 dark:text-white">
                          Invited via{' '}
                          <span className="font-mono-num">{pendingReferralCode}</span>
                        </span>{' '}
                        · Sign up to get 1 GB free credit for both of you.
                      </p>
                    </div>
                    <div className="flex items-center gap-1.5 shrink-0">
                      <button
                        type="button"
                        onClick={() => handleOpenAuth('transfers')}
                        className="rounded-lg bg-blue-700 hover:bg-blue-800 px-3 py-1.5 text-[12px] font-semibold text-white whitespace-nowrap transition-colors cursor-pointer"
                      >
                        Sign up &amp; claim 1 GB
                      </button>
                      <button
                        type="button"
                        onClick={clearPendingReferral}
                        aria-label="Dismiss referral invite"
                        className="flex h-7 w-7 items-center justify-center rounded-lg text-slate-500 hover:bg-blue-100 dark:hover:bg-blue-900/50 hover:text-slate-800 dark:hover:text-slate-200 transition-colors cursor-pointer"
                      >
                        <X className="h-3.5 w-3.5" />
                      </button>
                    </div>
                  </div>
                )}

                <p className="font-mono-num text-[11.5px] font-semibold uppercase tracking-[0.14em] text-blue-700 dark:text-blue-400">
                  Direct P2P · 7-Day Vault ·{' '}
                  <button
                    type="button"
                    onClick={openPWAInstallGuide}
                    className="uppercase underline decoration-blue-600/40 underline-offset-4 hover:text-blue-900 dark:hover:text-blue-200 cursor-pointer"
                  >
                    Installable Phone App
                  </button>
                </p>

                <h1 className="mt-4 font-display text-[42px] sm:text-[62px] lg:text-[70px] font-extrabold leading-[1.02] tracking-[-0.035em] text-slate-900 dark:text-white">
                  Large studio files.
                  <br />
                  Delivered direct,{' '}
                  <span className="brand-accent-text">web or phone.</span>
                </h1>

                <p className="mt-5 max-w-[540px] text-[16.5px] sm:text-[17.5px] leading-[1.6] text-slate-600 dark:text-slate-300">
                  Stream multi-gigabyte builds straight between browsers with zero server storage, or
                  upload once to a 7-day encrypted vault. Sign in with Google ID or Phone OTP and
                  pay per GB with UPI, cards, NetBanking, or wallets.
                </p>

                <div className="mt-7 flex flex-wrap items-center gap-3">
                  <button
                    type="button"
                    onClick={() => scrollToSend(true)}
                    className="brand-cta min-h-[46px] rounded-xl px-6 py-3 text-[15px] font-semibold text-white cursor-pointer"
                  >
                    Choose files to send
                  </button>
                  <PWAInstallButton />
                  <a
                    href="#delivery"
                    className="min-h-[46px] inline-flex items-center rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 px-5 py-3 text-[14.5px] font-semibold text-slate-900 dark:text-white hover:bg-slate-50 dark:hover:bg-slate-800 transition-colors"
                  >
                    Explore delivery
                  </a>
                </div>

                <p className="mt-3 text-[12.5px] text-slate-500 dark:text-slate-400">
                  Tip: drag &amp; drop files or folders anywhere in this hero to initiate an upload.
                </p>

                <ul className="mt-6 flex flex-wrap items-center gap-x-6 gap-y-2.5 text-[13.5px] font-medium text-slate-600 dark:text-slate-300">
                  <li className="inline-flex items-center gap-2">
                    <Lock className="h-4 w-4 text-blue-700 dark:text-blue-400" />
                    <span>DTLS encrypted streams</span>
                  </li>
                  <li className="inline-flex items-center gap-2">
                    <CreditCard className="h-4 w-4 text-blue-700 dark:text-blue-400" />
                    <span>UPI · Card · NetBanking · Wallet</span>
                  </li>
                  <li className="inline-flex items-center gap-2">
                    <RefreshCw className="h-4 w-4 text-blue-700 dark:text-blue-400" />
                    <span>Google ID &amp; Phone OTP</span>
                  </li>
                  <li className="inline-flex items-center gap-2">
                    <Folder className="h-4 w-4 text-blue-700 dark:text-blue-400" />
                    <span>Up to 20 TB P2P</span>
                  </li>
                </ul>
              </div>

              {/* Right Interactive Workbench */}
              <SendWorkbench
                currency={currency}
                onCurrencyChange={setCurrency}
                userLabel={userLabel}
                availableCreditGb={referralProfile?.creditGb ?? 0}
                savedPaymentMethods={paymentMethods}
                workbenchMode={workbenchMode}
                onWorkbenchModeChange={setWorkbenchMode}
                onOpenAuth={handleOpenAuth}
                triggerFilePickerSignal={pickerSignal}
                droppedBatch={heroDroppedBatch}
                minimized={workbenchMinimized}
                onMinimizeChange={handleMinimizeChange}
                onTransferToastUpdate={handleTransferToastUpdate}
                onTransferToastRemove={handleTransferToastRemove}
                onTransferRecorded={handleTransferRecorded}
                onTransferStatusSync={handleTransferStatusSync}
                onTransferDeleted={(code) => {
                  if (authUser) {
                    void deleteTransferHistoryRecord(authUser.uid, code).catch(() => {});
                  }
                }}
              />
            </div>
          </section>

          <LandingSections
            currency={currency}
            onChooseFilesClick={() => scrollToSend(true)}
            onOpenAuth={handleOpenAuth}
          />

          <PricingAndBottom
            currency={currency}
            onCurrencyChange={setCurrency}
            onSendClick={() => scrollToSend(false)}
            onOpenAuth={handleOpenAuth}
            onOpenLegal={setLegalDoc}
          />
        </main>
      )}

      <TransferToastContainer
        toasts={visibleToasts}
        onRestore={() => scrollToSend(false)}
        onDismiss={(code) =>
          setTransferToasts((prev) => dismissTransferToast(prev, code))
        }
      />

      <MobileBottomNav activeTab={mobileNavTab} onSelect={handleMobileNavSelect} />
      <OfflineIndicator />

      <AccountModal
        open={authModalOpen}
        initialTab={accountModalTab}
        user={authUser}
        authReady={authReady}
        historyEntries={historyEntries}
        historyLoading={historyLoading}
        historyError={historyError}
        paymentMethods={paymentMethods}
        paymentsLoading={paymentsLoading}
        paymentsError={paymentsError}
        referralProfile={referralProfile}
        profileError={profileError}
        onRetryProfileSync={() => void syncCurrentUserProfile()}
        referrals={referrals}
        referralsLoading={referralsLoading}
        referralsError={referralsError}
        pendingReferralCode={pendingReferralCode}
        onDismissPendingReferral={clearPendingReferral}
        onClose={() => setAuthModalOpen(false)}
        onGoogleSignIn={handleGoogleSignIn}
        onInitRecaptcha={createPhoneRecaptcha}
        onSendPhoneOtp={sendPhoneOtp}
        onFormatAuthError={formatFirebaseAuthError}
        onLogout={handleLogout}
        onDeleteHistoryEntry={handleDeleteHistoryEntry}
        onAddPaymentMethod={handleAddPaymentMethod}
        onSetDefaultPaymentMethod={handleSetDefaultPaymentMethod}
        onDeletePaymentMethod={handleDeletePaymentMethod}
      />

      <PWAInstallGuideModal />
      <LegalModal doc={legalDoc} onClose={() => setLegalDoc(null)} />
    </div>
  );
}
