import React from 'react';
import { Download, Smartphone, WifiOff } from 'lucide-react';
import { useOnlineStatus, usePWAInstall } from '../hooks/usePWAInstall';
import { openPWAInstallGuide, PWAInstallGuideModal } from './PWAInstallGuideModal';

export { openPWAInstallGuide, PWAInstallGuideModal };

export function PWAInstallButton({ compact = false }: { compact?: boolean }) {
  const { isInstallable, isInstalled, install } = usePWAInstall();

  if (isInstalled) {
    return null;
  }

  const handleClick = async () => {
    if (isInstallable) {
      const accepted = await install();
      if (accepted) return;
    }
    openPWAInstallGuide();
  };

  return (
    <button
      type="button"
      onClick={() => void handleClick()}
      className={
        compact
          ? 'inline-flex items-center gap-1.5 whitespace-nowrap shrink-0 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 px-3 py-2 text-[12.5px] font-semibold text-slate-800 dark:text-slate-100 hover:bg-slate-50 dark:hover:bg-slate-800 cursor-pointer min-h-[40px]'
          : 'inline-flex items-center gap-2 whitespace-nowrap shrink-0 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 px-4 py-2.5 text-[13.5px] font-semibold text-slate-900 dark:text-slate-100 hover:border-blue-600 transition-colors cursor-pointer min-h-[44px]'
      }
    >
      {isInstallable ? (
        <Download className="h-4 w-4 text-blue-600 dark:text-blue-400" />
      ) : (
        <Smartphone className="h-4 w-4 text-blue-600 dark:text-blue-400" />
      )}
      <span>{isInstallable ? 'Install Phone App' : 'Get Phone App'}</span>
    </button>
  );
}

export function OfflineIndicator() {
  const isOnline = useOnlineStatus();
  if (isOnline) return null;

  return (
    <div
      role="status"
      className="fixed bottom-20 md:bottom-4 left-4 z-50 flex items-center gap-2 rounded-xl border border-amber-300 bg-amber-50 dark:bg-amber-950/90 dark:border-amber-700 px-3.5 py-2 text-[12.5px] font-semibold text-amber-900 dark:text-amber-100 shadow-lg"
    >
      <WifiOff className="h-4 w-4 shrink-0" />
      <span>Offline — Cached app shell active</span>
    </div>
  );
}
