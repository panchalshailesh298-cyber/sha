import React from 'react';
import { QRCodeSVG } from 'qrcode.react';

interface QrCodeDisplayProps {
  url: string;
  size?: number;
  title?: string;
  subtitle?: string;
  className?: string;
}

export function QrCodeDisplay({
  url,
  size = 96,
  title = 'Scan on mobile to open receiver view',
  subtitle = 'Point any phone camera at this QR code to open the transfer link immediately.',
  className = '',
}: QrCodeDisplayProps) {
  if (!url.trim()) return null;

  return (
    <div
      data-testid="transfer-qr-card"
      className={`flex items-center gap-3.5 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50/80 dark:bg-slate-950/70 p-3 ${className}`}
    >
      <div
        data-testid="qr-code-display"
        className="shrink-0 overflow-hidden rounded-xl border border-slate-200 dark:border-slate-700 bg-white p-2 shadow-xs"
      >
        <QRCodeSVG
          value={url}
          size={size}
          level="M"
          bgColor="#ffffff"
          fgColor="#0f172a"
          title={`QR code for ${url}`}
        />
      </div>
      <div className="min-w-0 flex-1 space-y-1">
        <p className="text-[12.5px] font-semibold text-slate-900 dark:text-white">{title}</p>
        <p className="text-[11.5px] leading-snug text-slate-500 dark:text-slate-400">{subtitle}</p>
      </div>
    </div>
  );
}
