# Security Specification (`firestore.rules`)

## 1. Data Invariants
1. A `UserProfile` document at `/users/{userId}` can only be read, created, or updated by the verified Google- or Phone-OTP-authenticated user whose `request.auth.uid == userId`.
2. Every `ReferralCodeRecord` at `/referralCodes/{code}` is immutable, contains no email/phone PII, cannot be listed, and must belong to `request.auth.uid` on creation.
3. Every `ReferralRecord` at `/referrals/{referredUid}` is keyed by the referred user's UID (guaranteeing at most one referral redemption per signed-up account), forbids self-referral (`referrerUid != referredUid`), awards strictly `creditGb == 1`, and enforces atomic batch consistency with `/users/{referredUid}` on creation and `/users/{referrerUid}` on claim.
4. `creditGb` on `/users/{userId}` can only start at `0` (no referral) or `1` (atomically paired with `/referrals/{userId}`), can only increment by `+1` when atomically claiming an unclaimed `/referrals/{referredUid}` doc where `referrerUid == userId`, and can only decrement when atomically paired with a newly persisted `/users/{userId}/transfers/{transferCode}` doc.
5. Every `TransferHistoryRecord` at `/users/{userId}/transfers/{transferCode}` and `PaymentMethodRecord` at `/users/{userId}/paymentMethods/{methodId}` must belong to an existing parent `/users/{userId}` document whose `uid == request.auth.uid`, and `ownerUid` + document IDs are immutable after creation.
6. No unauthenticated or unverified user can read, list, create, update, or delete any document.

## 2. Adversarial "Dirty Dozen" Payloads (Expected: PERMISSION_DENIED)
1. Unauthenticated read of `/users/u1/transfers/abc12345` or `/referralCodes/JALPI8X2` (`request.auth == null`).
2. Authenticated user `u2` reading `/users/u1/transfers/abc12345` or `/users/u1` (cross-tenant PII read).
3. Unverified email token (`email_verified: false`) writing `/users/u1` or `/referrals/u1`.
4. Shadow/ghost field injection (`isAdmin: true`) in `/users/u1` create payload (`hasOnly` rejects).
5. Self-referral attack: user `u1` creating `/referrals/u1` with `referrerUid: "u1"` (`referrerUid != request.auth.uid` rejects).
6. Arbitrary credit inflation: user `u1` creating `/users/u1` with `creditGb: 999` without a referral, or updating `creditGb` from `0` to `100` directly.
7. Double-claim attack: referrer `u1` attempting to claim `/referrals/u2` a second time when `existing().referrerClaimed == true`.
8. Hijacked referral claim: user `u3` updating `/referrals/u2` where `existing().referrerUid == "u1"`.
9. Listing `/referralCodes` or listing `/referrals` without `referrerUid == request.auth.uid` / `referredUid == request.auth.uid` filter.
10. Modifying immutable fields (`ownerUid`, `code`, `referralCode`, `referredByUid`, or `createdAt`) on update.
11. Modifying a transfer whose existing `status == 'deleted'` (terminal state lock bypass).
12. Resource poisoning with >128-char IDs (`isValidId` rejects) or client-forged timestamps (`!= request.time`).
