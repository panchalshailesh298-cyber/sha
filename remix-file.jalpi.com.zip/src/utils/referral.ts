export interface ReferralRecord {
  referredUid: string;
  referredLabel: string;
  referrerUid: string;
  referralCode: string;
  creditGb: number;
  referrerClaimed: boolean;
  referredClaimed: boolean;
  createdAtMs: number;
}

export interface UserReferralProfile {
  referralCode: string;
  creditGb: number;
  referredByUid?: string;
  referredByCode?: string;
}

export interface ReferralSummary {
  availableCreditGb: number;
  friendsJoined: number;
  pendingClaims: number;
  totalEarnedGb: number;
}

const REFERRAL_CODE_REGEX = /^[a-zA-Z0-9_-]{6,32}$/;

export function normalizeReferralCode(raw: string | null | undefined): string | null {
  if (typeof raw !== 'string') return null;
  const trimmed = raw.trim();
  if (!REFERRAL_CODE_REGEX.test(trimmed)) return null;
  return trimmed;
}

export function parseReferralCodeFromSearch(search: string): string | null {
  if (!search) return null;
  const params = new URLSearchParams(search);
  return normalizeReferralCode(params.get('ref'));
}

export function generateReferralCode(uid: string): string {
  const alphabet = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
  const cleanedUid = uid.replace(/[^a-zA-Z0-9]/g, '').toUpperCase();
  const prefix = (cleanedUid.slice(0, 3) || 'JLP').padEnd(3, 'X');
  let suffix = '';
  for (let i = 0; i < 5; i += 1) {
    suffix += alphabet[Math.floor(Math.random() * alphabet.length)];
  }
  return `${prefix}${suffix}`;
}

export function buildReferralLink(origin: string, referralCode: string): string {
  const cleanOrigin = (origin || 'https://file.jalpi.com').trim().replace(/\/+$/, '') || 'https://file.jalpi.com';
  const normalized = normalizeReferralCode(referralCode);
  if (!normalized) return cleanOrigin;
  return `${cleanOrigin}/?ref=${encodeURIComponent(normalized)}`;
}

export function buildSafeReferralLabel(input: {
  displayName?: string | null;
  email?: string | null;
  phoneNumber?: string | null;
}): string {
  const rawName = (input.displayName || '').trim();
  if (rawName && !rawName.includes('@') && !/^\+?\d[\d\s-]{5,}$/.test(rawName)) {
    const parts = rawName.split(/\s+/).filter(Boolean);
    if (parts.length >= 2) {
      return `${parts[0]} ${parts[1][0].toUpperCase()}.`.slice(0, 80);
    }
    return parts[0].slice(0, 80);
  }
  if (input.email) {
    return 'Google Member';
  }
  if (input.phoneNumber) {
    return 'Phone Member';
  }
  return 'Jalpi Member';
}

export function summarizeReferrals(
  referrals: ReferralRecord[],
  creditGb: number,
  hasReferredBy: boolean
): ReferralSummary {
  const safeCredit = Math.max(0, Math.floor(Number(creditGb) || 0));
  const friendsJoined = referrals.length;
  const pendingClaims = referrals.filter((r) => !r.referrerClaimed).length;
  const referrerEarnedGb = referrals.reduce(
    (sum, r) => sum + (r.referrerClaimed ? r.creditGb : 0),
    0
  );
  const welcomeEarnedGb = hasReferredBy ? 1 : 0;

  return {
    availableCreditGb: safeCredit,
    friendsJoined,
    pendingClaims,
    totalEarnedGb: referrerEarnedGb + welcomeEarnedGb,
  };
}
