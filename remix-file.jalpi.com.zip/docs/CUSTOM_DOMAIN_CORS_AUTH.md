# Custom Domain (`file.jalpi.com`), CORS & Firebase Auth Setup

This document records the required configuration across the Express/Cloud Run backend, Google Cloud Storage (if direct-to-bucket uploads are enabled), and Firebase Authentication (`projectId: gen-lang-client-0716596360`) for serving **Share by Jalpi** on `https://file.jalpi.com` and Cloud Run preview URLs.

---

## 1. Express / Cloud Run Server CORS (Implemented in `server.ts`)

`server.ts` explicitly enables CORS and OAuth-popup compatibility headers for:

- `https://file.jalpi.com`
- `https://www.file.jalpi.com`
- `https://ais-pre-*.run.app` (Shared App URL)
- `https://ais-dev-*.run.app` (AI Studio Dev Preview URL)
- `https://*.a.run.app` (Cloud Run service URLs)
- `http://localhost:*` and `http://127.0.0.1:*`

Configured response headers:

- `Access-Control-Allow-Origin: <matched origin>`
- `Vary: Origin`
- `Access-Control-Allow-Credentials: true`
- `Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS`
- `Access-Control-Allow-Headers: Content-Type, Authorization, X-Requested-With`
- `Access-Control-Max-Age: 86400`
- `Cross-Origin-Opener-Policy: same-origin-allow-popups` (required so Google Sign-In popups do not break with `auth/popup-closed-by-user` on custom domains)

For the **Shared App URL** (`https://ais-pre-hlxryoctdwerdkz2qlpxew-831992995045.asia-southeast1.run.app`) or Cloud Run service URL, confirm **Cloud Run → Security → Authentication** is set to **Allow unauthenticated invocations**; otherwise external devices will be blocked before reaching Express.

---

## 2. Firebase Authentication Authorized Domains Checklist

App configuration (`firebase-applet-config.json`):

- **Project ID**: `gen-lang-client-0716596360`
- **Auth Domain**: `gen-lang-client-0716596360.firebaseapp.com`
- **Firestore Database ID**: `ai-studio-remixfilejalpico-dc762023-087a-442b-b8f8-8ef6bad31d47`
- **Storage Bucket**: `gen-lang-client-0716596360.firebasestorage.app`

In **Firebase Console → Authentication → Settings → Authorized domains**, ensure these domains are explicitly added (cannot be modified from client code):

1. `file.jalpi.com`
2. `www.file.jalpi.com`
3. `ais-pre-hlxryoctdwerdkz2qlpxew-831992995045.asia-southeast1.run.app`
4. Your deployed Cloud Run hostname (`<service>-<hash>.a.run.app`) if applicable

> Missing domains trigger `auth/unauthorized-domain` during Google Sign-In or Phone OTP reCAPTCHA verification.

---

## 3. Cloud Run Custom Domain & Optional Cloud Storage CORS

### A. Map `file.jalpi.com` to Cloud Run
1. Open **Google Cloud Console → Cloud Run → Manage Custom Domains → Add Mapping**.
2. Select your deployed service, map `file.jalpi.com` (and optionally `www.file.jalpi.com`), and add the displayed DNS `A`/`AAAA` or `CNAME` records at your DNS provider.
3. Wait for managed TLS certificate provisioning to finish (`status: Ready`).

### B. Apply Storage Bucket CORS (`cors-config.json`)
Run with Google Cloud CLI (`gcloud` / `gsutil`):

```bash
gsutil cors set cors-config.json gs://gen-lang-client-0716596360.firebasestorage.app
gsutil cors get gs://gen-lang-client-0716596360.firebasestorage.app
```
