import { initializeApp } from 'firebase/app';
import {
  ConfirmationResult,
  getAuth,
  GoogleAuthProvider,
  RecaptchaVerifier,
  signInWithPhoneNumber,
  signInWithPopup,
  signOut,
  User,
} from 'firebase/auth';
import {
  collection,
  deleteDoc,
  doc,
  getDoc,
  getDocFromServer,
  getFirestore,
  onSnapshot,
  query,
  runTransaction,
  serverTimestamp,
  setDoc,
  Timestamp,
  updateDoc,
  where,
  writeBatch,
} from 'firebase/firestore';
import firebaseConfig from '../firebase-applet-config.json';
import {
  buildSafeReferralLabel,
  generateReferralCode,
  normalizeReferralCode,
  ReferralRecord,
  UserReferralProfile,
} from './utils/referral';
import { Currency } from './utils/transferMath';
import {
  buildTransferShareUrl,
  PayerRole,
  PaymentGateway,
  PaymentMethod,
  PaymentRegion,
  PaymentStatus,
  SavedPaymentMethod,
  TransferHistoryEntry,
  TransferLifecycleStatus,
} from './utils/transferHistory';

const app = initializeApp(firebaseConfig);
export const db = getFirestore(app, firebaseConfig.firestoreDatabaseId);
export const auth = getAuth(app);
export const googleProvider = new GoogleAuthProvider();
googleProvider.setCustomParameters({ prompt: 'select_account' });

export enum OperationType {
  CREATE = 'create',
  UPDATE = 'update',
  DELETE = 'delete',
  LIST = 'list',
  GET = 'get',
  WRITE = 'write',
}

export interface FirestoreErrorInfo {
  error: string;
  operationType: OperationType;
  path: string | null;
  authInfo: {
    userId?: string | null;
    email?: string | null;
    phoneNumber?: string | null;
    emailVerified?: boolean | null;
    isAnonymous?: boolean | null;
    tenantId?: string | null;
    providerInfo?: {
      providerId?: string | null;
      email?: string | null;
    }[];
  };
}

export function handleFirestoreError(
  error: unknown,
  operationType: OperationType,
  path: string | null
): never {
  const errInfo: FirestoreErrorInfo = {
    error: error instanceof Error ? error.message : String(error),
    authInfo: {
      userId: auth.currentUser?.uid,
      email: auth.currentUser?.email,
      phoneNumber: auth.currentUser?.phoneNumber,
      emailVerified: auth.currentUser?.emailVerified,
      isAnonymous: auth.currentUser?.isAnonymous,
      tenantId: auth.currentUser?.tenantId,
      providerInfo:
        auth.currentUser?.providerData?.map((provider) => ({
          providerId: provider.providerId,
          email: provider.email,
        })) || [],
    },
    operationType,
    path,
  };
  console.error('Firestore Error: ', JSON.stringify(errInfo));
  throw new Error(JSON.stringify(errInfo));
}

async function testConnection() {
  try {
    await getDocFromServer(doc(db, 'test', 'connection'));
  } catch (error) {
    if (error instanceof Error && error.message.includes('the client is offline')) {
      console.error('Please check your Firebase configuration.');
    }
  }
}

void testConnection();

export function formatFirebaseAuthError(error: unknown): string {
  const code =
    typeof error === 'object' && error !== null && 'code' in error
      ? String((error as { code?: unknown }).code || '')
      : '';
  const msg = error instanceof Error ? error.message : String(error);

  if (code === 'auth/operation-not-allowed' || msg.includes('operation-not-allowed')) {
    return 'Phone OTP sign-in is not enabled yet in your Firebase project. Enable Authentication -> Sign-in method -> Phone in the Firebase Console (and add this domain under Authorized domains), or use Google Sign-In.';
  }
  if (code === 'auth/invalid-phone-number') {
    return 'Enter a valid phone number in international format (for example +919876543210).';
  }
  if (code === 'auth/invalid-verification-code') {
    return 'That 6-digit OTP code is incorrect. Check the SMS code and try again.';
  }
  if (code === 'auth/code-expired') {
    return 'The OTP code has expired. Request a fresh OTP code to continue.';
  }
  if (code === 'auth/too-many-requests') {
    return 'Too many OTP requests right now. Wait a moment or sign in with Google ID.';
  }
  if (code === 'auth/popup-closed-by-user' || code === 'auth/cancelled-popup-request') {
    return 'Google Sign-In popup was closed before finishing.';
  }
  if (code === 'auth/popup-blocked') {
    return 'Google Sign-In popup was blocked by your browser. Allow popups for this site or use Phone OTP below.';
  }
  if (code === 'auth/network-request-failed') {
    return 'Network error while contacting Firebase Authentication. Check your connection and try again.';
  }
  if (code === 'auth/unauthorized-domain') {
    return 'Add this app domain to Firebase Console -> Authentication -> Settings -> Authorized domains.';
  }
  return msg;
}

export async function signInWithGoogle() {
  return signInWithPopup(auth, googleProvider);
}

export function createPhoneRecaptcha(containerElement: HTMLElement): RecaptchaVerifier {
  return new RecaptchaVerifier(auth, containerElement, {
    size: 'invisible',
  });
}

export async function sendPhoneOtp(
  phoneE164: string,
  recaptcha: RecaptchaVerifier
): Promise<ConfirmationResult> {
  return signInWithPhoneNumber(auth, phoneE164, recaptcha);
}

export async function signOutUser() {
  return signOut(auth);
}

export interface EnsureProfileResult {
  redeemedReferral: boolean;
}

const inFlightProfileSyncs = new Map<string, Promise<EnsureProfileResult>>();

async function allocateUniqueReferralCode(uid: string): Promise<string> {
  for (let attempt = 0; attempt < 4; attempt += 1) {
    const candidate = generateReferralCode(uid);
    const snap = await getDoc(doc(db, 'referralCodes', candidate));
    if (!snap.exists()) {
      return candidate;
    }
  }
  return generateReferralCode(`${uid}${Date.now().toString(36)}`);
}

export async function ensureUserProfile(
  user: User,
  preferredCurrency: Currency,
  pendingReferralCode?: string | null
): Promise<EnsureProfileResult> {
  const existingPromise = inFlightProfileSyncs.get(user.uid);
  if (existingPromise) {
    return existingPromise;
  }

  const run = (async (): Promise<EnsureProfileResult> => {
    const userPath = `users/${user.uid}`;
    const ref = doc(db, 'users', user.uid);
    const email = user.email ? user.email.slice(0, 320) : undefined;
    const phoneNumber = user.phoneNumber ? user.phoneNumber.slice(0, 32) : undefined;
    const fallbackName = email ? email.split('@')[0] : phoneNumber || 'App User';
    const displayName = (user.displayName || fallbackName).slice(0, 120);
    const photoURL = user.photoURL ? user.photoURL.slice(0, 500) : undefined;
    const safeLabel = buildSafeReferralLabel({
      displayName: user.displayName,
      email: user.email,
      phoneNumber: user.phoneNumber,
    });

    try {
      const snap = await getDoc(ref);
      if (!snap.exists()) {
        const ownCode = await allocateUniqueReferralCode(user.uid);
        const codeRef = doc(db, 'referralCodes', ownCode);
        const batch = writeBatch(db);

        const normalizedPending = normalizeReferralCode(pendingReferralCode);
        let validReferrerUid: string | null = null;
        let validPendingCode: string | null = null;

        if (normalizedPending && normalizedPending !== ownCode) {
          const pendingCodeSnap = await getDoc(doc(db, 'referralCodes', normalizedPending));
          if (pendingCodeSnap.exists()) {
            const codeData = pendingCodeSnap.data();
            const ownerUid = typeof codeData.ownerUid === 'string' ? codeData.ownerUid : '';
            if (ownerUid && ownerUid !== user.uid) {
              validReferrerUid = ownerUid;
              validPendingCode = normalizedPending;
            }
          }
        }

        const payload: Record<string, unknown> = {
          uid: user.uid,
          displayName,
          preferredCurrency,
          referralCode: ownCode,
          creditGb: validReferrerUid ? 1 : 0,
          createdAt: serverTimestamp(),
          updatedAt: serverTimestamp(),
        };
        if (email) payload.email = email;
        if (phoneNumber) payload.phoneNumber = phoneNumber;
        if (photoURL) payload.photoURL = photoURL;
        if (validReferrerUid && validPendingCode) {
          payload.referredByUid = validReferrerUid;
          payload.referredByCode = validPendingCode;
        }

        batch.set(ref, payload);
        batch.set(codeRef, {
          code: ownCode,
          ownerUid: user.uid,
          referrerLabel: safeLabel,
          createdAt: serverTimestamp(),
        });

        if (validReferrerUid && validPendingCode) {
          batch.set(doc(db, 'referrals', user.uid), {
            referredUid: user.uid,
            referredLabel: safeLabel,
            referrerUid: validReferrerUid,
            referralCode: validPendingCode,
            creditGb: 1,
            referrerClaimed: false,
            referredClaimed: true,
            createdAt: serverTimestamp(),
            updatedAt: serverTimestamp(),
          });
        }

        await batch.commit();
        return { redeemedReferral: Boolean(validReferrerUid) };
      }

      const existingData = snap.data();
      const hasReferralFields =
        typeof existingData.referralCode === 'string' && typeof existingData.creditGb === 'number';

      if (!hasReferralFields) {
        const ownCode = await allocateUniqueReferralCode(user.uid);
        const batch = writeBatch(db);
        const migratePayload: Record<string, unknown> = {
          displayName,
          preferredCurrency,
          referralCode: ownCode,
          creditGb: 0,
          updatedAt: serverTimestamp(),
        };
        if (email) migratePayload.email = email;
        if (phoneNumber) migratePayload.phoneNumber = phoneNumber;
        if (photoURL) migratePayload.photoURL = photoURL;

        batch.update(ref, migratePayload);
        batch.set(doc(db, 'referralCodes', ownCode), {
          code: ownCode,
          ownerUid: user.uid,
          referrerLabel: safeLabel,
          createdAt: serverTimestamp(),
        });
        await batch.commit();
        return { redeemedReferral: false };
      }

      const updatePayload: Record<string, unknown> = {
        displayName,
        preferredCurrency,
        updatedAt: serverTimestamp(),
      };
      if (email) updatePayload.email = email;
      if (phoneNumber) updatePayload.phoneNumber = phoneNumber;
      if (photoURL) updatePayload.photoURL = photoURL;
      await updateDoc(ref, updatePayload);
      return { redeemedReferral: false };
    } catch (error) {
      handleFirestoreError(error, OperationType.WRITE, userPath);
    }
  })();

  inFlightProfileSyncs.set(user.uid, run);
  try {
    return await run;
  } finally {
    inFlightProfileSyncs.delete(user.uid);
  }
}

export function subscribeToUserProfile(
  uid: string,
  onData: (profile: UserReferralProfile | null) => void,
  onError: (err: Error) => void
): () => void {
  const path = `users/${uid}`;
  return onSnapshot(
    doc(db, 'users', uid),
    (snapshot) => {
      if (!snapshot.exists()) {
        onData(null);
        return;
      }
      const raw = snapshot.data();
      const referralCode = typeof raw.referralCode === 'string' ? raw.referralCode : '';
      const creditGb = Math.max(0, Math.floor(Number(raw.creditGb || 0)));
      const referredByUid =
        typeof raw.referredByUid === 'string' ? raw.referredByUid : undefined;
      const referredByCode =
        typeof raw.referredByCode === 'string' ? raw.referredByCode : undefined;
      if (!referralCode) {
        onData(null);
        return;
      }
      onData({
        referralCode,
        creditGb,
        referredByUid,
        referredByCode,
      });
    },
    (error) => {
      try {
        handleFirestoreError(error, OperationType.GET, path);
      } catch (wrapped) {
        onError(wrapped instanceof Error ? wrapped : new Error(String(wrapped)));
      }
    }
  );
}

export function subscribeToReferrals(
  uid: string,
  onData: (referrals: ReferralRecord[]) => void,
  onError: (err: Error) => void
): () => void {
  const colPath = 'referrals';
  const q = query(collection(db, 'referrals'), where('referrerUid', '==', uid));
  return onSnapshot(
    q,
    (snapshot) => {
      const items: ReferralRecord[] = snapshot.docs.map((d) => {
        const raw = d.data();
        const createdTs = raw.createdAt instanceof Timestamp ? raw.createdAt.toMillis() : Date.now();
        return {
          referredUid: String(raw.referredUid || d.id),
          referredLabel: String(raw.referredLabel || 'Jalpi Member'),
          referrerUid: String(raw.referrerUid || uid),
          referralCode: String(raw.referralCode || ''),
          creditGb: Math.max(1, Number(raw.creditGb || 1)),
          referrerClaimed: Boolean(raw.referrerClaimed),
          referredClaimed: Boolean(raw.referredClaimed),
          createdAtMs: createdTs,
        };
      });
      items.sort((a, b) => b.createdAtMs - a.createdAtMs);
      onData(items);
    },
    (error) => {
      try {
        handleFirestoreError(error, OperationType.LIST, colPath);
      } catch (wrapped) {
        onError(wrapped instanceof Error ? wrapped : new Error(String(wrapped)));
      }
    }
  );
}

export async function claimReferralReward(
  referrerUid: string,
  referredUid: string
): Promise<void> {
  const path = `referrals/${referredUid}`;
  const referralRef = doc(db, 'referrals', referredUid);
  const userRef = doc(db, 'users', referrerUid);
  try {
    await runTransaction(db, async (tx) => {
      const [refSnap, userSnap] = await Promise.all([tx.get(referralRef), tx.get(userRef)]);
      if (!refSnap.exists() || !userSnap.exists()) return;
      const refData = refSnap.data();
      if (refData.referrerClaimed === true) return;
      const currentCredit = Math.max(0, Math.floor(Number(userSnap.data().creditGb || 0)));
      tx.update(referralRef, {
        referrerClaimed: true,
        updatedAt: serverTimestamp(),
      });
      tx.update(userRef, {
        creditGb: currentCredit + 1,
        lastClaimedReferralUid: referredUid,
        updatedAt: serverTimestamp(),
      });
    });
  } catch (error) {
    handleFirestoreError(error, OperationType.UPDATE, path);
  }
}

export interface SaveTransferHistoryInput {
  code: string;
  headline: string;
  fileCount: number;
  totalBytes: number;
  billedGb: number;
  creditAppliedGb?: number;
  mode: 'p2p' | 'server';
  destination: string;
  currency: Currency;
  priceAmount: number;
  priceFormatted: string;
  paymentGateway: PaymentGateway;
  paymentMethod: PaymentMethod;
  payerRole: PayerRole;
  paymentStatus: PaymentStatus;
  status: TransferLifecycleStatus;
  shareUrl: string;
}

export async function saveTransferToHistory(
  ownerUid: string,
  input: SaveTransferHistoryInput
): Promise<void> {
  const cleanCode = input.code.slice(0, 32);
  const path = `users/${ownerUid}/transfers/${cleanCode}`;
  const ref = doc(db, 'users', ownerUid, 'transfers', cleanCode);
  const userRef = doc(db, 'users', ownerUid);
  const requestedCredit = Math.max(0, Math.floor(Number(input.creditAppliedGb || 0)));
  const transferPayload = {
    code: cleanCode,
    ownerUid,
    headline: input.headline.slice(0, 180) || cleanCode,
    fileCount: Math.max(1, Math.min(100000, Math.round(input.fileCount))),
    totalBytes: Math.max(0, Number(input.totalBytes) || 0),
    billedGb: Math.max(1, Math.min(25000, Math.round(input.billedGb))),
    creditAppliedGb: Math.min(25000, requestedCredit),
    mode: input.mode,
    destination: input.destination.slice(0, 180) || 'Direct P2P',
    currency: input.currency,
    priceAmount: Math.max(0, Number(input.priceAmount) || 0),
    priceFormatted: input.priceFormatted.slice(0, 32),
    paymentGateway: input.paymentGateway,
    paymentMethod: input.paymentMethod,
    payerRole: input.payerRole,
    paymentStatus: input.paymentStatus,
    status: input.status,
    shareUrl: input.shareUrl.slice(0, 240),
    createdAt: serverTimestamp(),
    updatedAt: serverTimestamp(),
  };

  try {
    if (requestedCredit > 0) {
      await runTransaction(db, async (tx) => {
        const userSnap = await tx.get(userRef);
        const liveCredit = userSnap.exists()
          ? Math.max(0, Math.floor(Number(userSnap.data().creditGb || 0)))
          : 0;
        const actualCredit = Math.min(25000, requestedCredit, liveCredit);
        tx.set(ref, {
          ...transferPayload,
          creditAppliedGb: actualCredit,
        });
        if (actualCredit > 0 && userSnap.exists()) {
          tx.update(userRef, {
            creditGb: liveCredit - actualCredit,
            lastTransferCode: cleanCode,
            updatedAt: serverTimestamp(),
          });
        }
      });
    } else {
      await setDoc(ref, transferPayload);
    }
  } catch (error) {
    handleFirestoreError(error, OperationType.CREATE, path);
  }
}

export async function updateTransferHistoryStatus(
  ownerUid: string,
  code: string,
  status: TransferLifecycleStatus
): Promise<void> {
  const path = `users/${ownerUid}/transfers/${code}`;
  const ref = doc(db, 'users', ownerUid, 'transfers', code);
  try {
    await updateDoc(ref, {
      status,
      updatedAt: serverTimestamp(),
    });
  } catch (error) {
    handleFirestoreError(error, OperationType.UPDATE, path);
  }
}

export async function deleteTransferHistoryRecord(
  ownerUid: string,
  code: string
): Promise<void> {
  const path = `users/${ownerUid}/transfers/${code}`;
  const ref = doc(db, 'users', ownerUid, 'transfers', code);
  try {
    await deleteDoc(ref);
  } catch (error) {
    handleFirestoreError(error, OperationType.DELETE, path);
  }
}

export function subscribeToTransferHistory(
  ownerUid: string,
  onData: (entries: TransferHistoryEntry[]) => void,
  onError: (err: Error) => void
): () => void {
  const colPath = `users/${ownerUid}/transfers`;
  const q = query(
    collection(db, 'users', ownerUid, 'transfers'),
    where('ownerUid', '==', ownerUid)
  );
  return onSnapshot(
    q,
    (snapshot) => {
      const items: TransferHistoryEntry[] = snapshot.docs.map((d) => {
        const raw = d.data();
        const createdTs = raw.createdAt instanceof Timestamp ? raw.createdAt.toMillis() : Date.now();
        const rawMethod = String(raw.paymentMethod || 'card');
        const method: PaymentMethod =
          rawMethod === 'upi' ||
          rawMethod === 'netbanking' ||
          rawMethod === 'wallet' ||
          rawMethod === 'card'
            ? rawMethod
            : 'card';
        return {
          code: String(raw.code || d.id),
          ownerUid: String(raw.ownerUid || ownerUid),
          headline: String(raw.headline || d.id),
          fileCount: Number(raw.fileCount || 1),
          totalBytes: Number(raw.totalBytes || 0),
          billedGb: Number(raw.billedGb || 1),
          creditAppliedGb: Number(raw.creditAppliedGb || 0),
          mode: raw.mode === 'server' ? 'server' : 'p2p',
          destination: String(raw.destination || 'Direct P2P'),
          currency: raw.currency === 'INR' ? 'INR' : 'USD',
          priceAmount: Number(raw.priceAmount || 0),
          priceFormatted: String(raw.priceFormatted || '$0.50'),
          paymentGateway: raw.paymentGateway === 'razorpay' ? 'razorpay' : 'stripe',
          paymentMethod: method,
          payerRole: raw.payerRole === 'receiver' ? 'receiver' : 'sender',
          paymentStatus: raw.paymentStatus === 'pending_receiver' ? 'pending_receiver' : 'paid',
          status: (raw.status as TransferLifecycleStatus) || 'ready',
          shareUrl: buildTransferShareUrl(String(raw.code || d.id)),
          createdAtMs: createdTs,
        };
      });
      items.sort((a, b) => b.createdAtMs - a.createdAtMs);
      onData(items);
    },
    (error) => {
      try {
        handleFirestoreError(error, OperationType.LIST, colPath);
      } catch (wrapped) {
        onError(wrapped instanceof Error ? wrapped : new Error(String(wrapped)));
      }
    }
  );
}

export interface AddPaymentMethodInput {
  label: string;
  region: PaymentRegion;
  gateway: PaymentGateway;
  method: PaymentMethod;
  detail: string;
  isDefault: boolean;
}

export async function addSavedPaymentMethod(
  ownerUid: string,
  input: AddPaymentMethodInput,
  existingMethods: SavedPaymentMethod[]
): Promise<void> {
  const id = `pm_${Date.now().toString(36)}_${Math.random().toString(36).slice(2, 6)}`;
  const path = `users/${ownerUid}/paymentMethods/${id}`;
  const ref = doc(db, 'users', ownerUid, 'paymentMethods', id);
  const shouldBeDefault = input.isDefault || existingMethods.length === 0;

  try {
    const batch = writeBatch(db);
    if (shouldBeDefault) {
      for (const m of existingMethods) {
        if (m.isDefault) {
          batch.update(doc(db, 'users', ownerUid, 'paymentMethods', m.id), {
            isDefault: false,
            updatedAt: serverTimestamp(),
          });
        }
      }
    }
    batch.set(ref, {
      id,
      ownerUid,
      label: input.label.slice(0, 60),
      region: input.region,
      gateway: input.gateway,
      method: input.method,
      detail: input.detail.slice(0, 120),
      isDefault: shouldBeDefault,
      createdAt: serverTimestamp(),
      updatedAt: serverTimestamp(),
    });
    await batch.commit();
  } catch (error) {
    handleFirestoreError(error, OperationType.CREATE, path);
  }
}

export async function setDefaultPaymentMethod(
  ownerUid: string,
  targetId: string,
  existingMethods: SavedPaymentMethod[]
): Promise<void> {
  const path = `users/${ownerUid}/paymentMethods/${targetId}`;
  try {
    const batch = writeBatch(db);
    for (const m of existingMethods) {
      const nextDefault = m.id === targetId;
      if (m.isDefault !== nextDefault) {
        batch.update(doc(db, 'users', ownerUid, 'paymentMethods', m.id), {
          isDefault: nextDefault,
          updatedAt: serverTimestamp(),
        });
      }
    }
    await batch.commit();
  } catch (error) {
    handleFirestoreError(error, OperationType.UPDATE, path);
  }
}

export async function deleteSavedPaymentMethod(
  ownerUid: string,
  methodId: string
): Promise<void> {
  const path = `users/${ownerUid}/paymentMethods/${methodId}`;
  try {
    await deleteDoc(doc(db, 'users', ownerUid, 'paymentMethods', methodId));
  } catch (error) {
    handleFirestoreError(error, OperationType.DELETE, path);
  }
}

export function subscribeToPaymentMethods(
  ownerUid: string,
  onData: (methods: SavedPaymentMethod[]) => void,
  onError: (err: Error) => void
): () => void {
  const colPath = `users/${ownerUid}/paymentMethods`;
  const q = query(
    collection(db, 'users', ownerUid, 'paymentMethods'),
    where('ownerUid', '==', ownerUid)
  );
  return onSnapshot(
    q,
    (snapshot) => {
      const items: SavedPaymentMethod[] = snapshot.docs.map((d) => {
        const raw = d.data();
        const createdTs = raw.createdAt instanceof Timestamp ? raw.createdAt.toMillis() : Date.now();
        const rawMethod = String(raw.method || 'card');
        const method: PaymentMethod =
          rawMethod === 'upi' ||
          rawMethod === 'netbanking' ||
          rawMethod === 'wallet' ||
          rawMethod === 'card'
            ? rawMethod
            : 'card';
        return {
          id: String(raw.id || d.id),
          ownerUid: String(raw.ownerUid || ownerUid),
          label: String(raw.label || 'Payment Method'),
          region: raw.region === 'IN' ? 'IN' : 'GLOBAL',
          gateway: raw.gateway === 'razorpay' ? 'razorpay' : 'stripe',
          method,
          detail: String(raw.detail || ''),
          isDefault: Boolean(raw.isDefault),
          createdAtMs: createdTs,
        };
      });
      items.sort((a, b) => Number(b.isDefault) - Number(a.isDefault) || b.createdAtMs - a.createdAtMs);
      onData(items);
    },
    (error) => {
      try {
        handleFirestoreError(error, OperationType.LIST, colPath);
      } catch (wrapped) {
        onError(wrapped instanceof Error ? wrapped : new Error(String(wrapped)));
      }
    }
  );
}
