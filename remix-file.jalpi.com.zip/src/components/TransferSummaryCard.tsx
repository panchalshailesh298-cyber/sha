import React, { useEffect, useState } from 'react';
import { ChevronDown, ChevronUp, Clock, FileText, ShieldCheck } from 'lucide-react';
import { formatMethodLabel, PaymentMethod } from '../utils/transferHistory';
import { TransferMode } from '../utils/transferMath';
import {
  formatExpirationIndicator,
  summarizeTransferFiles,
  TransferSummaryFileItem,
} from '../utils/transferSummary';

export interface TransferSummaryData {
  code: string;
  mode: TransferMode;
  paid: boolean;
  receiverPays: boolean;
  paymentGateway?: 'razorpay' | 'stripe';
  paymentMethod?: PaymentMethod;
  destination?: string;
  totalBytes: number;
  billedGb: number;
  priceFormatted: string;
  expiresAt: string;
  files: TransferSummaryFileItem[];
}

interface TransferSummaryCardProps {
  transfer: TransferSummaryData;
}

export function TransferSummaryCard({ transfer }: TransferSummaryCardProps) {
  const [showAllFiles, setShowAllFiles] = useState(false);
  const [nowMs, setNowMs] = useState(() => Date.now());

  useEffect(() => {
    setNowMs(Date.now());
    const timer = window.setInterval(() => {
      setNowMs(Date.now());
    }, 30_000);
    return () => window.clearInterval(timer);
  }, [transfer.code, transfer.expiresAt]);

  const expiration = formatExpirationIndicator(transfer.expiresAt, transfer.mode, nowMs);
  const fileSummary = summarizeTransferFiles(transfer.files, transfer.mode, showAllFiles, 4);
  const gatewayLabel = transfer.paymentGateway === 'razorpay' ? 'Razorpay' : 'Stripe';
  const methodLabel = transfer.paymentMethod ? formatMethodLabel(transfer.paymentMethod) : 'Card';
  const billingStatus = transfer.receiverPays
    ? `Receiver pays ${transfer.priceFormatted}`
    : `${transfer.priceFormatted} · ${gatewayLabel} ${methodLabel}`;

  const urgencyStyles =
    expiration.urgency === 'expired'
      ? {
          container:
            'border-red-200 dark:border-red-900/70 bg-red-50/75 dark:bg-red-950/35 text-red-900 dark:text-red-200',
          iconWrap: 'bg-red-100 dark:bg-red-900/60 text-red-700 dark:text-red-300',
          subtext: 'text-red-700/90 dark:text-red-300/90',
          barFill: 'bg-red-600',
          barTrack: 'bg-red-200/70 dark:bg-red-900/50',
        }
      : expiration.urgency === 'soon'
      ? {
          container:
            'border-amber-200 dark:border-amber-800/80 bg-amber-50/85 dark:bg-amber-950/35 text-amber-950 dark:text-amber-100',
          iconWrap: 'bg-amber-100 dark:bg-amber-900/60 text-amber-800 dark:text-amber-300',
          subtext: 'text-amber-800/90 dark:text-amber-300/90',
          barFill: 'bg-amber-500',
          barTrack: 'bg-amber-200/70 dark:bg-amber-900/50',
        }
      : {
          container:
            'border-emerald-200 dark:border-emerald-800/70 bg-emerald-50/70 dark:bg-emerald-950/30 text-emerald-950 dark:text-emerald-100',
          iconWrap: 'bg-emerald-100 dark:bg-emerald-900/60 text-emerald-700 dark:text-emerald-300',
          subtext: 'text-emerald-800/90 dark:text-emerald-300/90',
          barFill: 'bg-emerald-600',
          barTrack: 'bg-emerald-200/70 dark:bg-emerald-900/50',
        };

  return (
    <div
      data-testid="transfer-summary-card"
      className="rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900/80 overflow-hidden divide-y divide-slate-200 dark:divide-slate-800"
    >
      {/* Header + Billing Overview */}
      <div className="px-4 py-3 flex flex-wrap items-baseline justify-between gap-2 bg-slate-50/75 dark:bg-slate-950/50">
        <div className="min-w-0">
          <h4 className="font-display text-[13.5px] font-bold text-slate-900 dark:text-white">
            Transfer summary
          </h4>
          <p className="mt-0.5 text-[11.5px] text-slate-500 dark:text-slate-400 truncate">
            {transfer.mode === 'server' ? '7-Day Vault' : 'Direct P2P'} · {transfer.billedGb} GB billed ·{' '}
            {billingStatus}
          </p>
        </div>
        <span className="font-mono-num tabular-nums text-[12px] font-semibold text-slate-700 dark:text-slate-300">
          #{transfer.code}
        </span>
      </div>

      {/* Prominent Expiration Time Indicator */}
      <div
        data-testid="transfer-expiration-indicator"
        className={`px-4 py-3 ${urgencyStyles.container}`}
      >
        <div className="flex items-center justify-between gap-3">
          <div className="flex items-center gap-2.5 min-w-0">
            <span
              className={`inline-flex h-8 w-8 shrink-0 items-center justify-center rounded-lg ${urgencyStyles.iconWrap}`}
            >
              <Clock className="h-4 w-4" aria-hidden="true" />
            </span>
            <div className="min-w-0">
              <p className="font-mono-num tabular-nums text-[13px] font-bold leading-tight">
                {expiration.remainingLabel}
              </p>
              <p className={`mt-0.5 text-[11.5px] leading-tight ${urgencyStyles.subtext}`}>
                {expiration.exactDateLabel}
              </p>
            </div>
          </div>

          <span
            className={`shrink-0 text-right font-mono-num tabular-nums text-[11px] font-medium ${urgencyStyles.subtext}`}
          >
            {expiration.windowLabel}
          </span>
        </div>

        <div
          aria-hidden="true"
          className={`mt-2.5 h-1.5 w-full overflow-hidden rounded-full ${urgencyStyles.barTrack}`}
        >
          <div
            className={`h-full rounded-full transition-all duration-300 ${urgencyStyles.barFill}`}
            style={{ width: `${expiration.remainingPercent}%` }}
          />
        </div>
      </div>

      {/* Distinct File Details Section */}
      <div data-testid="transfer-file-details" className="bg-white dark:bg-slate-900/60">
        <div className="px-4 py-2.5 flex items-center justify-between gap-2 border-b border-slate-100 dark:border-slate-800/80 bg-slate-50/40 dark:bg-slate-950/30">
          <span className="text-[12px] font-semibold text-slate-800 dark:text-slate-200">
            File details
          </span>
          <span className="font-mono-num tabular-nums text-[11.5px] font-medium text-slate-600 dark:text-slate-400">
            {fileSummary.summaryLabel}
          </span>
        </div>

        <ul className="divide-y divide-slate-100 dark:divide-slate-800/70">
          {fileSummary.visibleFiles.map((file) => (
            <li
              key={file.key}
              className="px-4 py-2.5 flex items-center justify-between gap-3 text-[12.5px]"
            >
              <div className="flex items-center gap-2.5 min-w-0 flex-1">
                <FileText
                  className="h-3.5 w-3.5 shrink-0 text-slate-400 dark:text-slate-500"
                  aria-hidden="true"
                />
                <span
                  title={file.displayName}
                  className="truncate font-medium text-slate-800 dark:text-slate-100"
                >
                  {file.displayName}
                </span>
              </div>

              <div className="flex items-center gap-3 shrink-0 font-mono-num tabular-nums text-[11.5px]">
                <span className="inline-flex items-center gap-1 text-emerald-700 dark:text-emerald-400">
                  <ShieldCheck className="h-3 w-3" aria-hidden="true" />
                  <span>{file.statusLabel}</span>
                </span>
                <span className="text-slate-600 dark:text-slate-400 min-w-[54px] text-right">
                  {file.sizeLabel}
                </span>
              </div>
            </li>
          ))}
        </ul>

        {(fileSummary.hiddenCount > 0 || (transfer.files.length > 4 && showAllFiles)) && (
          <div className="px-4 py-2 border-t border-slate-100 dark:border-slate-800/70">
            <button
              type="button"
              onClick={() => setShowAllFiles((prev) => !prev)}
              className="inline-flex items-center gap-1 text-[12px] font-semibold text-blue-700 dark:text-blue-400 hover:underline cursor-pointer"
            >
              {showAllFiles ? (
                <>
                  <ChevronUp className="h-3.5 w-3.5" />
                  <span>Show fewer files</span>
                </>
              ) : (
                <>
                  <ChevronDown className="h-3.5 w-3.5" />
                  <span>Show all {transfer.files.length} files (+{fileSummary.hiddenCount} more)</span>
                </>
              )}
            </button>
          </div>
        )}
      </div>
    </div>
  );
}
